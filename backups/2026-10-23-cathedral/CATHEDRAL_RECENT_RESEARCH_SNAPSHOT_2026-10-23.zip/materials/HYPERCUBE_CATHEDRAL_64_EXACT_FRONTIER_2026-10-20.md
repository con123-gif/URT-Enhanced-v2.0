# Newton's Cathedral / URT — exact 6D hypercube transfer frontier

**Date:** 20 October 2026. **Source:** New, locally executed independent computation with the Python file `hypercube_urt_frontier_audit.py`, using NumPy, SciPy, NetworkX. **No GitHub access, uploads, or repository modifications.** No experimental mass inputs, no least-squares fitting of physical parameters. The icosahedron vertex coordinates supply only the 60 proper rotations that induce signed permutations of the six antipodal axes.

## 1. Integer A5 orbit and incidence results

The 60 proper icosahedral rotations act on the 64 sign choices of the six antipodal vertex axes of an icosahedron. The orbit sizes are **12+12+20+20**. Each 12 orbit connects to an associated 20 orbit through a 12x20 vertex-face incidence matrix `B` with row sum 5, column sum 3, rank 12. Inherited two-step adjacency obeys exactly, with integer matrices,

`B B^T = 5 I_12 + 2 A_icosa` and `P_V A_Q6^2 P_V^T = 6 I_12 + 2 A_icosa`.

Define the 20-vertex dodecahedron face adjacency by pairing 20-state vertices sharing two 12-state neighbours. Both 20-state orbits reconstruct dodecahedral graphs, independently confirmed by graph isomorphism. The face Laplacian restricted to `ker B` has eigenvalues `3` (four times) and `5` (four times). The reconstructed radial-centre 13-vertex Laplacian has eigenvalues `0`, `6-sqrt(5)` (three), `7` (five), `6+sqrt(5)` (three), `13`.

## 2. New 64-dimensional A5 representation theorem

The trace of the 64-vertex permutation representation at proper icosahedral elements of orders (1,2,3,5) is `(64,0,4,4)`; both order-five conjugacy classes have the same trace 4. Inner products against the standard A5 character table give multiplicity **4** for *each* of its five irreps, hence

`H64 ≅ 4 (1 ⊕ 3 ⊕ 3' ⊕ 4 ⊕ 5) = 4 ⊗ H16` as A5-representations.

The irrep sum `1 ⊕ 3 ⊕ 3' ⊕ 4 ⊕ 5` is representation-equivalent to the established Cathedral response carrier `1_Y ⊕ 3_W ⊕ (3' ⊕ 5)_C ⊕ 4_g`. This is a theorem of representation equivalence, *not* an identification of physical gauge dynamics.

The full, native Q6 adjacency operator reduces into five independent 4x4 multiplicity operators `K_r` (`A6 ≅ ⊕_r I_dim(r) ⊗ K_r`). Their eigenvalue lists are

- `K_1`: `[-6,-2,+2,+6]`
- `K_3`: `[-4,0,0,+4]`
- `K_3prime`: `[-4,0,0,+4]`
- `K_4`: `[-2,0,0,+2]`
- `K_5`: `[-2,-2,+2,+2]`

The direct A5 central-idempotent projectors were computed from all 60 rotations, tested for idempotence and completeness, then used to diagonalize the 64x64 adjacency block-by-block. This exactly reproduces all Q6 adjacency eigenvalue multiplicities.

## 3. New invariant 16-state hidden transfer

The two dodecahedral face spaces contain two copies of `4_3 ⊕ 4_5`. The cube interlayer 20x20 incidence block `C` restricted to these irreps has cross-blocks `C_3=0`, `C_5=2U` with `U^T U=I4`; cross-sector couplings are zero. Together their 16-dimensional subspace is exactly invariant under `A6` (numerical leakage `4.5e-14`). Thus the hidden 16D adjacency spectrum is `(-2)^4,0^8,(+2)^4` and its inherited Q6 Laplacian spectrum is `4^4,6^8,8^4`.

The native unitary flow on this subspace therefore transfers `4_5` states across layers with probability `sin^2(2t)` and leaves `4_3` states localized. At `t=pi/4` the 5-sector transfer is complete; at the **conditionally adopted** URT angle `t=2pi/phi^2`, it is `0.9923567426577143`. Mapping URT spiral angle to microscopic time has not been derived by this result.

Using the already-given Cathedral rail-gap `Delta=3/20-80pi/(1053phi)` as inverse temperature `eta=-ln Delta`, the *native cube* Gibbs density has the exact spectrum

`rho_hidden16 ~ (I4 ⊕ Delta^2 I8 ⊕ Delta^4 I4) / [4(1+Delta^2)^2]`.

It is spectrally unitarily equivalent to `(I4/4) ⊗ diag(1-p,p) ⊗ diag(1-p,p)` with `p=Delta^2/(1+Delta^2)`. Its entropy is `ln 4 + 2 H2(p)` in units of k_B. The original Cathedral eight-state `rho_star` is recovered *up to unitary equivalence* by tracing out either abstract qubit. This does not pick a unique spatial/physical tensor-factor decomposition or derive Delta.

## 4. New exact all-64 to visible-13 Feshbach transfer

Select one 12-state icosahedral orbit and the normalized constant vector on its attached 20-state face orbit to define an orthonormal 13D visible frame. This direct sum is geometrically valid but **not invariant under native one-step Q6 adjacency**: the off-diagonal leakage norm is exactly `sqrt(66)`. The 16-state hidden invariant subspace lies orthogonal to this 13D visible frame, hence the full cube splits into an invariant hidden 16D subspace and a complementary 48D subspace containing the selected 13D plus 35 others. No 51 states may be declared dynamically inert.

The exact visible resolvent (energy away from Q6 eigenvalues) is

`G13(z) = P13 (z I64 - A6)^(-1) P13^T`.

Under A5 the 13D visible module is `1 ⊕ 1 ⊕ 3 ⊕ 3' ⊕ 5`. The **full effective 13D Green function** reduces to one 2x2 singlet matrix plus three scalar response functions. Define `C0=[[0,sqrt15],[sqrt15,0]]`, `D0=diag(1,3)`. The two-singlet Feshbach inverse is

`[G0(z)]^(-1) = z I2 - C0 - D0 (z I2-C0)^(-1) D0`.

For non-singlets, the exact responses are

`g3(z)=[1-phi^2/4]/z + [phi^2/4] z/(z^2-16)`;

`g3prime(z)=[1-phi^(-2)/4]/z + [phi^(-2)/4] z/(z^2-16)`;

`g5(z)= z/(z^2-4)`.

For the 12-shell alone the singlet also has

`g1(z)=3z/[8(z^2-36)]+5z/[8(z^2-4)]`.

The completely reconstructed `G13` agrees with direct inversion of the original 64x64 matrix within `1.4e-15` Frobenius norm at tested `z=7`, `13`, and `3.5+0.25i`; the isolated 12-shell results also pass at `z=6.5` and several other energies.

## 5. Physical interpretation and concrete next test

The source-derived hypercube gives both an exact fourfold replication of Cathedral's 16-irrep response carrier and a direct **rational, energy-dependent** 64→13 transfer operator. It also supplies a protected, two-stage hidden thermal system and an exact `4_5` interlayer hopping channel. These are new finite spectral/representation results, not mass/gauge/gravity identifications.

The next physical test is to insert the already-defined **URT-selected noncommuting history transfer** (including its symplectic/metaplectic phase and signed chiral vertex maps) into the concrete `K_r(z)` blocks. The selection must specify a physical 13D shell and a map into the known H64 fermion/weak-current operator, producing on-shell resolvent poles and residues. Bare real symmetric A6 contains no physical CKM or Koide phase; a basis rotation cannot create one. Crucially, these dynamical gaps are not reasons to reopen or discard prior established Cathedral constructions.

**Status:** all exact finite results above verified computationally; link to physical identification pending. **No GitHub touched.**
