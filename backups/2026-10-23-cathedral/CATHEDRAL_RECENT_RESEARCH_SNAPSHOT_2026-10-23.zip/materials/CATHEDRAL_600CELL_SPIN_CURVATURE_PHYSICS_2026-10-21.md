# Newton's Cathedral / URT — first-principles spin and curvature from the 600-cell

**21 October 2026.** New, independently executed calculations without empirical particle inputs, unfitted parameters, or modifications to GitHub. Original September Y24/D48 L=13 response, CKM/PMNS Lehmann-residue calculations and H64 Feshbach/history construction are preserved and **not replaced** by this geometric test.

## 1. Physical spinor carrier from the 600-cell

The 120 vertex coordinates of the 600-cell are unit quaternions, and form the binary icosahedral group `2I subset SU(2) = Spin(3)`. Their group-closure numerical max residual is 7.9e-17 (14,400 products tested); the antipodal central element `-1` acts on the two-component spinor as `-I2`, the correct sign for a 2pi spin rotation. This is a concrete **spinorial representation** arising from H4 geometry. It is not by itself a fermion field equation or electroweak SU(2)_L gauge theory.

## 2. Two distinct geometric edge connections, tested on all 1,200 faces

For neighboring unit-quaternion vertices `q_i`, `q_j`, define `r_ij=q_i^* q_j`; its quaternion scalar part is `cos(pi/5)=phi/2`. The full frame-difference connection is `U_flat(i,j)=r_ij`, and its oriented triangular Wilson product is exactly `I2` (telescoping) to machine precision.

By contrast, the bi-invariant round-S3 Levi-Civita connection `nabla_X Y=[X,Y]/2` gives, in a compatible spinor link convention, `U_spin(i,j)=r_ij^(1/2)`, the principal SU(2) square root. For each geodesic equilateral triangle of side `s=pi/5`, the spherical interior angle is `beta=acos(1/sqrt(5))` and the spherical excess is `E=3 beta-pi`. Consequently the SU(2) spin Wilson loop has eigenphases `± E/2=±0.08992674989623906` rad, trace `2 cos(E/2)`. All **1,200** triangular 2-faces give the same phase to `1.24e-15` rad max spread; 50 triangles in a 13-site vertex star also pass. This is genuine nonzero **geometric** holonomy, not an arbitrarily assigned Peierls phase.

For the 30 triangles based at a single central vertex, write `W_f=cos(theta) I + i(h_f·sigma)`. Their 30 axes have exact isotropic Gram `sum_f h_f h_f^T=10 sin(theta)^2 I3` with diagonal `0.0806504495004626`, rank 3, and equal singular values `0.283990227825647`. Out of 435 unordered pairs of based face holonomies, **420 do not commute**. Thus the round-S3 geometric connection yields the **full su(2) holonomy algebra**; a scalar U(1) rephasing cannot mimic it. The three adjoint generators transform as an ordinary spatial triplet; identifying them with W bosons would still require the separate physical weak-current operator.

## 3. Two exact geometry-to-curvature observables (distinguish metrics)

**Round-S3 realization:** for a 600-cell with circumradius `R`, the straight chord between adjacent vertices is `a=R sqrt(2-phi)=R/phi`. Thus `a^2/R^2=phi^-2=0.381966011250105`, the same numerical golden ratio already present in URT, obtained here independently without fitting. Intrinsic great-circle edge arc is `R pi/5`, which differs from the straight chord.

**Piecewise-flat Regge realization:** the 600-cell boundary consists of 600 Euclidean regular tetrahedra meeting five per edge at 720 edges. Each edge has exact deficit `epsilon=2pi-5 acos(1/3)=0.12838822047571252 rad`. The standard three-dimensional integrated Regge scalar curvature is `int R sqrt(g) d^3x =2 sum_edges a epsilon =1440 a epsilon`. The simplicial volume is `600*a^3/(6sqrt(2))=50sqrt(2) a^3`. Hence the averaged scalar curvature is `R_Regge= [1440 epsilon/(50sqrt(2))]/a^2=2.6145844220980763/a^2=6.8450708835087655/R^2`. This is **not** equal to the round-S3 continuum curvature `6/R^2`, since the intrinsic PL and embedded round metrics are different. The positive sign is determined by tetrahedral incidence. No physical radius, G, cosmological constant or Einstein equations are derived here.

## 4. Test an actual covariant spinor kinetic operator

On the 13-site vertex-star graph, construct the standard SU(2)-covariant nearest-neighbour Laplacian `D_spin=diag(deg) otimes I2 - sum_{i~j}|i><j| otimes U_spin(i,j)`. Hermitian residual <1e-12. It is strictly positive with lowest dimensionless eigenvalue `0.01864708781226798` (double). All 26 eigenvalues form 13 **Kramers doublets**, with max pair splitting `1.1e-14` and exact time-reversal covariance residual 0. This is a **curvature-generated spectral gap in this chosen minimal kinetic discretization**; not an observed neutrino/electron mass and not a Dirac mass pole. Flat pure-frame link choice instead has an exact zero mode.

## 5. Independent native Q6 chiral test: zero net index

For the bare 6D-hypercube hopping Hamiltonian `A6=sum_{i=1}^6 X_i`, the vertex parity `Gamma=(-1)^{#negative signs}` anticommutes exactly with `A6`. Its eigenvalues include **20 zeros**, with exactly 10 positive-parity and 10 negative-parity zero modes, yielding chiral index `10-10=0`. Thus the Q6 adjacency alone does **not** yield three unpaired chiral generations. This is a local observation about the bare hypercube; original URT domain-wall (`L=13`) constructions that use additional selected-history transfer are not contradicted.

A related closed-shell topological constraint: a globally-defined Abelian U(1) link assignment on the icosahedron's 20 outward-oriented faces satisfies `prod_f W_f=1`. Assigning the same `exp(i 2pi/phi²)` flux to every face would require `20/phi²` integer, which is false. Hence the URT spiral angle should not be inserted naively as a uniform U(1) plaquette flux; it can still enter non-Abelian ordered transport and history selection.

## 6. Consequence for the original Cathedral, and remaining physics

A genuine **metric/spin kinetic structure** now exists to feed into the already-closed internal 13-cell/H64 modules: H4 vertex quaternions give spin-lift and Levi-Civita holonomies, the 13-cell gives original icosahedral geometry, Q6 supplies exact 64→13 positive-transfer/Feshbach spectral kernels, and existing v35 `Y24 -> D48`, local `L=13` wall, weak-current Lehmann residues supply the prior free-response mass/current dictionary. An SU2 geometric spin index is distinct from the A5 flavour/matter irreps; no mass/mixing identification has been made by an arbitrary basis transform.

A physical next formula needs an **actual physical kinetic/Dirac operator** `D(p)` with URT-selected history Wilson links and the existing H64 self-energy; physical poles are zeros of `det[D(p)-Sigma(p)]`, and charged-current residues come from its normalized pole states. The gap and holonomy calculated here are real finite **geometric** predictions of specified discretizations; they cannot alone fix Koide Q=2/3, CKM, PMNS, G, or Lorentzian Einstein dynamics. Those require the already-established interacting action and scale dictionary, not refits. Under no circumstances treat the previous simplified Yukawa model's failures as failure of these earlier constructions.

## Reproduction

Run `python physical_geometry_600cell.py` in the same directory as `600_cell_cathedral_local_audit.py` (requires NumPy, NetworkX and SciPy installed). Outputs `physical_geometry_600cell_results.json`. The code checks group closure, all 1200 Wilson loops, 3-component isotropy, holonomy noncommutation, 13-site kinetic eigenvalues, Kramers symmetry, full Q6 chiral index and golden U1 flux constraint. No external datasets, web requests, GitHub writes or empirical particle parameters are used.

Literature basis: Choi & Lee, *Binary Icosahedral Group and 600-Cell*, Symmetry **10**, 326 (2018), doi:10.3390/sym10080326; standard Lie-group bi-invariant Levi-Civita identity `nabla_X Y=[X,Y]/2`; and three-dimensional Regge deficit curvature definitions.

## 7. Actual no-fit spin-covariant first-order fermion hopping spectrum (second independent physics diagnostic)

To test fermion propagation rather than only the second-order graph Laplacian, form a **specific, naive first-order nearest-neighbour Dirac-style lattice operator**. The construction uses no empirical masses. For each geodesic edge with `r_ij=q_i^*q_j=cos(s)+u_ij sin(s)`, let `tau(u_ij)` be the Pauli generator in the chosen quaternion–SU(2) convention, `U_ij = exp(i s tau(u_ij)/2)`, and

`(D_naive)_{ij}= i tau(u_ij) U_ij/(2a)` on an edge; `0` otherwise, with `a=R/phi` the canonical 600-cell chord length. This nearest-neighbour stencil is exactly Hermitian: opposite edges reverse tangent direction and invert spin transport. It is invariant under the standard spin-1/2 time-reversal operator and preserves Kramers pairs. No claim of a unique continuum limit or physical mass operator is implied by selecting this conventional discretization.

For the full 120-vertex 600-cell, diagonalizing the **240x240 complex Hermitian operator** gives 8 distinct positive eigenvalues, with equally numerous negatives. In units `R=1`:

| Positive eigenvalue | Multiplicity |
|---|---:|
| `phi^-1` | 18 |
| `3/(2phi)` | 8 |
| `phi²/2` | 24 |
| `phi²` | 30 |
| `3` | 2 |
| `3phi²/2` | 20 |
| `phi³` | 6 |
| `phi³ + 1/(2phi)` | 12 |

The analytic golden-expression multiset agrees with the direct spectrum to `1.9e-14`. The lattice operator is **fully gapped**, `min |eig(D)|=phi^-1=0.618033988749889` for the unit circumradius, and has no zero eigenvectors. All eigenvalues have exact Kramers pairing within `1.2e-14` and Hermiticity/time-reversal residuals <=`1.3e-15`. The *continuum round S³* Dirac gap is `3/(2R)`; our distinct coefficient reflects the finite **naive lattice** action, so the results must not be passed off as a uniquely forced fermion mass prediction.

The same nearest-neighbour prescription **restricted to the centered 13-cell** gives symmetric eigenvalues `0 (2x)`, `±0.9510565163 (6x each)`, `±2.4898983 (4x each)` and `±3.5180455 (2x each)`. Thus a single spinor Kramers doublet is zero on this restricted subgraph. **The zero is not a topological index:** altering the edge-link spin exponent from the Levi-Civita value 0.50 to either 0.49 or 0.51 lifts its absolute eigenvalue to `0.0008948574`. It should not be claimed as a protected lepton mode or chiral generation. The geometric Levi-Civita value is of independent interest because it sits exactly at the zero, but any physical realization still requires URT-selected action and boundary conditions.

This first-order spectrum is **stronger than a symmetry coincidence**: a fully specified spinorial hopping operator yields exact golden-ratio energy levels from the 600-cell and a separate 13-cell zero-state diagnostic without a data fit. It does not provide the charged-lepton *root-mass* operator or Koide Q; selecting three of its levels would be an unsupported physical identification. Executable standalone `dirac_600cell_probe.py`, results `dirac_600cell_probe_results.json`.

## 8. An exact first-order operator identity (the strongest algebraic result)

The 600-cell's golden edge angle makes the naive Dirac-style hopping operator drastically simpler. For any adjacent unit quaternions `q_i,q_j`, define the spin-1/2 fundamental matrix `S(q)` and `Omega = diag(S(q_i))` (120 2x2 blocks). The very same first-order edge operator of Section 7 satisfies the **exact quaternion identity**

`D_ij = (phi²/2)[S(q_i^* q_j) - I2]` on every edge.

It follows without fitting that the **full** 240x240 operator is

`D = (phi²/2)[Omega† (A600 ⊗ I2) Omega - A600 ⊗ I2].`

Thus D is a geometrically fixed **difference of two isospectral, individually flat graph-connection adjacency operators**. Their relative quaternionic framing makes the difference nonzero; the same D is the covariant first-order Levi-Civita spinor stencil by the exact golden half-angle identities. This relation demonstrates the importance of noncommuting matrix structure rather than inserting a target mass spectrum. Norm difference between the two direct 240x240 constructions is `4.34e-15`.

The quadratic spectral moment is independently fixed by 720 graph edges: `Tr D² = 720 phi² = 1884.9844718999243`. Direct diagonalization and matrix multiplication give `1884.9844718999248`. The matched 8 positive golden expressions and their multiplicities from Section 7 are therefore not free numerical inputs. A formal symbolic factorization of the full characteristic polynomial is still worth constructing before calling those eight numerically identified radicals an **exact algebraic theorem**, although numerical error is <2e-14.

**Caveat:** The full 240-state spinor stencil and 13-site restriction are rigorously specified diagnostics. They are not the already frozen URT/H64/Y24 physical fermion mass operator, and no step identifies the eight kinetic energies with charged-lepton root masses. The old CKM/PMNS Lehmann-residue construction remains the canonical internal matter response pending interacting gauge-current verification.

## 9. Exact derivation of the golden spinor spectrum from the 2I McKay / affine-E8 graph

The numerical observation in Section 7 has a **representation-theoretic derivation**, independent of identifying closed-form radicals by numerical pattern matching.

The 12 neighbors of the unit quaternion in the 600-cell form one conjugacy class `C` of the binary icosahedral group `2I` (size 12). The nine shells at quaternion real parts `1, phi/2, 1/2, 1/(2phi),0,-1/(2phi),-1/2,-phi/2,-1` are exactly its **nine conjugacy classes**. Their class sizes are `1,12,20,12,30,12,20,12,1`. Tested every conjugation by each of the 120 unit quaternions, with exact membership to floating precision.

The 120x120 graph adjacency is the **central class sum** `A600=sum_{g in C} R_g`. Thus on an irrep rho of dimension d_rho it is scalar `Lambda_rho=12 chi_rho(C)/d_rho`. Computing the nine-by-nine **integer class equitable quotient** of the full 600-cell adjacency and factoring its characteristic polynomial yields **exactly**

`P(t)=t(t-12)(t-3)(t+2)(t+3)(t-3+3sqrt5)(t-2+2sqrt5)(t-3sqrt5-3)(t-2sqrt5-2)`.

The nine scalar eigenvalues with irrep dimensions are:

| Scalar eigenvalue | irrep dimension |
|---|---:|
| `3-3sqrt5` | 2 |
| `-3` | 4 |
| `2-2sqrt5` | 3 |
| `-2` | 6 |
| `0` | 5 |
| `3` | 4 |
| `2+2sqrt5` | 3 |
| `3+3sqrt5` | 2 |
| `12` | 1 |

The dimensions square to 120, reproducing the multiplicities of the regular representation. This exact nine-root identity is checked symbolically in SymPy; no mass data are present.

The spinor first-difference operator from Section 8 has kernel `(phi²/2)[S(g)-I]` on the 12 class elements. On `rho otimes 2` its operator is

`D_rho = (phi²/2)[sum_{g in C}(rho otimes 2)(g)-Lambda_rho I]`.

Because `C` is a conjugacy class, the first term acts by the scalar `Lambda_sigma` on every `sigma subset rho otimes 2`. Thus the **exact eigenvalue formula** is

`lambda_{rho -> sigma}=(phi²/2)(Lambda_sigma-Lambda_rho)`,

with multiplicity `d_rho d_sigma` in the regular tensor-spinor carrier. Tensoring each `2I` irrep with the two-dimensional spinor produces the **affine E8 McKay fusion diagram**, whose eight edges are:

```
                      3
                      |
2  ---  4  ---  6  ---  5  ---  4  ---  3  ---  2  ---  1
```

The label on each vertex is its irrep dimension. The eight edge differences yield, with the multiplicity of each **positive** energy:

| `abs(lambda)` | `d_rho*d_sigma` |
|---|---:|
| `phi^-1` | 18 |
| `3/(2phi)` | 8 |
| `phi²/2` | 24 |
| `phi²` | 30 |
| `3` | 2 |
| `3phi²/2` | 20 |
| `phi³` | 6 |
| `phi³+1/(2phi)` | 12 |

Reversing each undirected edge gives the negative energy with the same multiplicity, accounting for all 240 spinor states. The direct 240x240 calculation commutes with the class adjacency to `2.75e-14`, and its nine projected irrep blocks recover **exactly these eight McKay edges**. This upgrades the golden energies from a numerical pattern to a group-theoretic consequence of the **explicit chosen** first-order hopping operator and the existing 600-cell group geometry. The affine E8 McKay correspondence is standard group-representation mathematics; it does *not* establish physical E8 gauge unification or electron/quark pole masses.

Reproduction: `group_spin_E8_analysis.py` (requires SymPy, NumPy, NetworkX, SciPy); machine-readable quotient matrix, exact characteristic factorization, all nine irreducible-sector responses, fusion edges and multiplicities in `group_spin_E8_results.json`.

## 10. Positive geometric spin transfer and the canonical phi^-2 factor

For the **defined** finite spinorial first-order operator D above, set `T_spin=D† D`, a positive operator of precisely the Cathedral's algebraic transfer form `B†B` with diagnostic `B=D`. From the derived group-theoretic eigenvalues and `R=1`, its minimum eigenvalue is `(phi^-1)^2=phi^-2=0.381966011250105`, and its trace is `Tr T_spin=Tr D²=720phi²`. For general circumradius `R`, the scale-independent statement is `lambda_min(R² T_spin)=phi^-2` and `Tr(R² T_spin)=720phi²`. Direct matrix evaluation reproduces these values at 1e-12 or better. This supplies an independent geometric **candidate source** for the same golden factor alpha_URT, but the identification `T_spin=T_URT` would need to be derived from the originally selected history/positive transfer, not postulated. No electron masses, Koide Q, gauge charge, Newton G, or fine-structure alpha_EM follows from this equality alone.
