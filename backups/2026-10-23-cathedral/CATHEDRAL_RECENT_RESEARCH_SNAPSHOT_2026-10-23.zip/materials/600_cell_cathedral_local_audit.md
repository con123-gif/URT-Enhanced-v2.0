# 600-cell / Newton's Cathedral: independently checked local H4→H3→13+8 construction

**Executed 21 October 2026, no GitHub or connected repositories used.** This is mathematics, not a prediction of measured particle masses.

## Exact vertices

Set phi=(1+sqrt(5))/2. Build the 120 unit-radius H4 vertices from eight coordinate axes (±1,0,0,0), the sixteen sign vectors (±1/2,±1/2,±1/2,±1/2), and the 96 vectors obtained from even coordinate permutations and eight signings of (0,1/2,phi/2,1/(2phi)). Connect two vertices precisely when their inner product equals phi/2 (distance=1/phi). This yields a 12-regular 120-vertex graph with 720 edges, the 600-cell graph.

Choose v=(1,0,0,0). It has 12 neighbours. Their induced graph has 30 edges and is isomorphic to the icosahedral graph. Its 20 triangles are the vertex figure's faces, equivalent to the 20 tetrahedral cells adjacent to v in the full 600-cell face lattice.

## Exact centred 13-vertex local graph

The induced graph on v and its 12 neighbours has 42 edges. Its Laplacian has exact spectrum

  0(1), (6-sqrt5)(3), 7(5), (6+sqrt5)(3), 13(1).

This is the previously established centred Cathedral G13 spectrum. The largest computed eigenvalue error is 5.33e-15.

## Local face incidence and eight hidden modes

Define B in R^{12x20} by B_{i,F}=1 if icosahedron vertex i belongs to triangular face F; zero otherwise. Every vertex belongs to 5 faces; every adjacent pair belongs to 2 faces, therefore

  BB^T=5I+2A_ico.

The icosahedron adjacency has eigenvalues 5(1),sqrt5(3),-1(5),-sqrt5(3), so BB^T has eigenvalues 15(1),(5+2sqrt5)(3),3(5),(5-2sqrt5)(3), all strictly positive: rank(B)=12, dim ker(B)=8. Connect triangular faces whenever they share an edge; this is the dodecahedral graph. Its Laplacian preserves ker(B) and restricts there with eigenspectrum 3(4),5(4). Numerical invariance leakage ≈9.96e-15.

**Scope warning**: the 20 faces are abstract local incidence states, not 20 of the 120 vertex states. This result alone does not prove that the eight face-kernel states embed in the physical 120-vertex Hamiltonian or that the 600-cell generates gauge or fermion poles.

## The remarkable 64-state golden-layer selection

The 120 vertex inner products with v occur at 1,phi/2,1/2,1/(2phi),0,-1/(2phi),-1/2,-phi/2,-1 with multiplicities 1,12,20,12,30,12,20,12,1. The union of four layers at |dot|=phi/2 or 1/2 contains 64 vertices in A5 orbit types (12,20,20,12). The corresponding permutation module is isomorphic as an A5 representation to the earlier Q6 64-sign configuration construction. Its character is (64,0,4,4,4) on the five A5 conjugacy classes; using character orthogonality yields multiplicity four of each irrep 1,3,3',4,5, hence 64=4*16.

However, the **induced 600-cell adjacency** on those 64 vertices is not the six-dimensional cube adjacency. It has 240 edges, two connected components of 32 vertices, and degrees six (40 vertices) and ten (24 vertices). Q6 adjacency has 192 edges and is connected and 6-regular. Therefore the identification is **symmetry-level**, not native-dynamics-level. A physical URT operator selecting among these inequivalent A5-equivariant kernels has not yet been derived.

## Interpretation and what is not claimed

The H4 600-cell supplies a separate independent route to the Cathedral G13 and eight local hidden modes, complementing the 6D hypercube realization. It also supplies an A5-equivariant 64-state permutation module with the same irreducible representation content as the hypercube realization. None of this alone fixes the charged-lepton Koide invariant Q=2/3, a particle mass, or the physical photon current.

Published background: Jihyeon Lee et al., *Binary Icosahedral Group and 600-Cell*, Symmetry 10 (2018) 326, https://www.mdpi.com/2073-8994/10/8/326 ; Al-Siyabi et al., *Icosahedral Polyhedra from D6 Lattice and Danzer's ABCK Tiling*, Symmetry 12 (2020) 1983, https://www.mdpi.com/2073-8994/12/12/1983 . The Mathematica classification dates to Schlaefli's 1852 work, published in full posthumously 1901. The 600-cell has 14400 full symmetries, whereas the 24-cell has 1152.

Reproduce: `python 600_cell_cathedral_local_audit.py`. Generates `600_cell_cathedral_local_audit_results.json` and asserts all primary spectral, graph, rank and connectivity claims.
