import runpy,contextlib,io,json
from pathlib import Path
import numpy as np
from scipy.linalg import null_space
from itertools import combinations
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
 r=runpy.run_path(str(p/'600_cell_cathedral_local_audit.py'))
q=r['vertices']; A=r['A600'];inds=r['idx']; faces=r['faces']; B=r['B'];L=r['L20']; phi=r['phi'];
def mul(a,b):
 w,x,y,z=a;W,X,Y,Z=b
 return np.array([w*W-x*X-y*Y-z*Z,w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W])
ids={tuple(np.round(v,10)):i for i,v in enumerate(q)}
def indx(v):return ids[tuple(np.round(v,10))]
h=set(range(24)); unvisited=set(range(120)); cosets=[]
while unvisited:
 k=min(unvisited); coset={indx(mul(q[k],q[j])) for j in h};cosets.append((k,coset));unvisited-=coset
assert len(cosets)==5
fmap={tuple(sorted(f)):i for i,f in enumerate(faces)};loc={int(n):a for a,n in enumerate(inds)}
def perm(g):
 a=q[g];bar=a*np.array([1,-1,-1,-1]);return [loc[indx(mul(mul(a,q[k]),bar))] for k in inds]
def face_perm(g):
 permu=perm(g)
 return [fmap[tuple(sorted(permu[j] for j in f))] for f in faces]
# Reference A4 face orbits
orbits=[];unseen=set(range(20))
while unseen:
 k=min(unseen);orb={face_perm(j)[k] for j in h};orbits.append(sorted(orb));unseen-=orb
assert sorted(len(orb) for orb in orbits)==[4,4,12]
small=[o for o in orbits if len(o)==4]; print('reference small orbits:',small)
K=null_space(B); d,U=np.linalg.eigh(K.T@L@K);H=np.column_stack((K@U[:,:4],K@U[:,4:]));
Ws=[]
for rep,c in cosets:
 f=face_perm(rep)
 a=[f[j] for j in small[0]];b=[f[j] for j in small[1]]
 D=np.diag([int(j in a)-int(j in b) for j in range(20)])
 W=H.T@D@H
 assert np.linalg.norm(W[:4,:4])<1e-12 and np.linalg.norm(W[4:,4:])<1e-12
 print('coset',rep,'singular',np.round(np.linalg.svd(W[:4,4:],compute_uv=False),10))
 Ws.append(W)
Ws=np.array(Ws); gram=np.einsum('aij,bij->ab',Ws,Ws)
print('HS GRAM\n',np.round(gram,8));print('SUM W norm',np.linalg.norm(Ws.sum(axis=0)))
print('COMMUTATORS norm\n',np.round([[np.linalg.norm(a@b-b@a) for b in Ws] for a in Ws],8))
# algebra dimension incremental closure using real matrices; full 8x8 real algebra may have dimension 64
I=np.eye(8);basis=[];raw=[]
def add(m):
 x=np.asarray(m,float).reshape(-1);v=x.copy()
 for u in basis:v-=np.dot(u,v)*u
 n=np.linalg.norm(v)
 if n>1e-8:
  basis.append(v/n);raw.append(m);return True
 return False
add(I)
for w in Ws:add(w)
for iteration in range(20):
 prev=len(raw);layer=list(raw)
 for a in layer:
  for w in Ws:
   add(a@w)
 if len(raw)==prev:break
 if len(raw)>=64:break
 print('Algebra iter',iteration,'dimension',len(raw))
print('ALGEBRA DIMENSION',len(raw))
# eigenvalues of H16 with 5 sequentially selected gates weighted by URT q phases; no empirical input
Delta=3/20-(80/81)*np.pi/(13*phi);kappa=np.pi/np.e;theta=2*np.pi/phi**2
Lh=np.diag([3.]*4+[5.]*4); C=np.diag([0.]*4+[-2.]*4)
for name,wts in [('equal',np.ones(5)),('spiral_real',np.array([kappa**j*np.cos(j*theta) for j in range(5)])),('spiral_antisym',np.array([kappa**j*np.sin(j*theta) for j in range(5)]))]:
 wcomb=np.einsum('a,aij->ij',wts,Ws)
 h16=np.block([[Lh+Delta*wcomb,C],[C,Lh+Delta*wcomb]])
 sp=np.linalg.eigvalsh(h16)
 low=sp[sp<3.1]
 print(name,'weights',np.round(wts,6),'W norm',np.linalg.norm(wcomb),'comm W,L',np.linalg.norm(wcomb@Lh-Lh@wcomb),'spectrum near3',np.round(low,10))
# trace unitary orient ordered product at effective scale small, independent of empirical masses
from scipy.linalg import expm
for d in [Delta,0.1,0.3,1.0]:
 U=np.eye(8,dtype=complex)
 for w in Ws:U=expm(1j*d*w)@U
 vals=np.sort(np.angle(np.linalg.eigvals(U)))
 print('holonomy order d',d,'eigenphase',np.round(vals,10),'comm loop',np.linalg.norm(U-np.eye(8)))
result={'coset_count':len(cosets),'orbit_sizes':[len(x) for x in orbits],'HS_gram':gram.tolist(),'W_sum_norm':float(np.linalg.norm(Ws.sum(axis=0))),'operator_algebra_dimension':len(raw),'delta':Delta,'spiral_theta':theta,'spiral_kappa':kappa}
(p/'five_tetrahedral_orientations_results.json').write_text(json.dumps(result,indent=2)+'\n')
