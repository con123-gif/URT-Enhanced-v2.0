import runpy, contextlib, io, itertools, json
from pathlib import Path
import numpy as np
from scipy.linalg import null_space
from collections import Counter
with contextlib.redirect_stdout(io.StringIO()):
 r=runpy.run_path(str(Path(__file__).resolve().parent/'600_cell_cathedral_local_audit.py'))
q=r['vertices']; Av=r['A600']; ci=r['central']; inds=r['idx']; face=r['faces']; B=r['B']; L=r['L20']; phi=r['phi'];
# quaternion product wxyz
def mul(a,b):
 w,x,y,z=a; W,X,Y,Z=b
 return np.array([w*W-x*X-y*Y-z*Z,w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W])
idxOf={tuple(np.round(v,10)):i for i,v in enumerate(q)}
def indx(v):
 key=tuple(np.round(v,10));
 if key not in idxOf:raise ValueError(f'not closed {key}')
 return idxOf[key]
h=set(range(24))
assert {indx(mul(q[a],q[b])) for a in h for b in h}==h
unseen=set(range(120)); cosets=[]
while unseen:
 g=min(unseen); c={indx(mul(q[g],q[j])) for j in h}; assert len(c)==24
 cosets.append(sorted(c));unseen-=c
assert len(cosets)==5 and not unseen
print('cosets',len(cosets),'sizes',[len(v) for v in cosets])
class_verts=np.array([next(i for i,c in enumerate(cosets) if k in c) for k in range(120)])
print('local shell coset populations', Counter(class_verts[inds]))
# restricted rotational conjugation by binary tetrahedral H, group projects 12 distinct SO3 rotations
maps=[]; unique=set()
for a in sorted(h):
 qa=q[a]; bar=qa*np.array([1,-1,-1,-1]); perm=tuple(indx(mul(mul(qa,q[k]),bar)) for k in inds)
 if perm not in unique: maps.append(perm);unique.add(perm)
assert len(maps)==12
# maps should be set of 12 global indices, local reference ordering map
loc={int(n):a for a,n in enumerate(inds)}
perms=[[loc[x] for x in p] for p in maps]
assert set(perms[0])==set(range(12))
# orbit of faces under these automorphisms
face_idx={tuple(sorted(f)):i for i,f in enumerate(face)}
face_perms=np.array([[face_idx[tuple(sorted(perm[j] for j in f))] for f in face] for perm in perms])
unseen=set(range(20)); faceorbits=[]
while unseen:
 k=min(unseen);orb=sorted({int(x) for x in face_perms[:,k]});faceorbits.append(orb);unseen-=set(orb)
print('face orbit sizes under A4',list(map(len,faceorbits)))
# compare Laplacian hidden eigenspaces
K=null_space(B)
ls,V=np.linalg.eigh(K.T@L@K)
print('hidden eigs',np.round(ls,9))
H3=K@V[:,:4];H5=K@V[:,4:]
assert np.linalg.norm(B@H3)<1e-12 and np.linalg.norm(B@H5)<1e-12
print('A5 hidden subspaces',np.linalg.norm(H3.T@H5),np.linalg.norm(B@H3),np.linalg.norm(B@H5))
for orb in faceorbits:
 D=np.diag([int(j in orb) for j in range(20)])
 K=H3.T@D@H5
 print('orbit',len(orb),'hidden-3/5 mixing norm',np.linalg.norm(K),'singular_values',np.round(np.linalg.svd(K,compute_uv=False),12))
# Bilinear representations: compare 4x4 to 16 decomposition under A5; use exact character table inner products
# 4⊗4 = 1+3+3prime+4+5: A5 chars classes 1,2,3,5a,5b; class sizes 1,15,20,12,12
ph=(1+np.sqrt(5))/2
class_size=np.array([1,15,20,12,12])
chi4=np.array([4,0,1,-1,-1],float)
irr={'1':[1,1,1,1,1], '3':[3,-1,0,ph,1-ph],"3p":[3,-1,0,1-ph,ph],'4':[4,0,1,-1,-1], '5':[5,1,-1,0,0]}
for name,chi in irr.items():
 m=np.dot(class_size,chi4**2*np.array(chi))/60
 print('multiplicity',name,m)
# 5 coset permutation rep of A5: character by trace of left coset action; A5 5 point action gives (5,1,2,0,0) = 1+4
chi5=np.array([5,1,2,0,0])
assert np.allclose(chi5,chi4+1)
# Restrict 3 and3prime to A4: 1 identity 3 elements order2 8 elements order3
# A5 3 character on these= (3,-1,0). inner product 1 => unique Hom
hom=(3*3+3*(-1)*(-1)+8*0*0)/12
print('Hom_A4(3,3prime)=',hom)
from sympy import Matrix, eye, diag, Rational, simplify
bs=Matrix([[int(x) for x in row] for row in B])
Ls=Matrix([[int(x) for x in row] for row in L])
Pk=eye(20)-bs.T*(bs*bs.T).inv()*bs
P3=(5*eye(20)-Ls)*Pk/2
P5=(Ls-3*eye(20))*Pk/2
assert (Pk*Pk-Pk)==Matrix.zeros(20,20)
assert (P3*P3-P3)==Matrix.zeros(20,20)
assert (P5*P5-P5)==Matrix.zeros(20,20)
for orbit in faceorbits:
 if len(orbit)!=4:continue
 Ds=diag(*[int(j in orbit) for j in range(20)])
 Op=P3*Ds*P5*Ds*P3
 tr1=Op.trace(); tr2=(Op*Op).trace()
 # minimal polynomial, zero eigen allowed
 poly=Op*(Op-Rational(3,20)*eye(20))*(Op-Rational(1,60)*eye(20))
 print('exact orbit',orbit,'Tr M',tr1,'Tr M²',tr2,'rank',Op.rank(),'minpoly residual zero',poly==Matrix.zeros(20,20))
 print('D33 eigs',np.linalg.eigvalsh(H3.T@np.array(Ds.tolist(),float)@H3))
 print('D55 eigs',np.linalg.eigvalsh(H5.T@np.array(Ds.tolist(),float)@H5))
 evals=np.linalg.eigvalsh(np.column_stack((H3,H5)).T@(L+np.array(Ds.tolist(),float))@np.column_stack((H3,H5)))
 print('L_hidden + orbit face gate spectrum',np.round(evals,12))
D_a=np.diag([int(j in faceorbits[1]) for j in range(20)])
D_b=np.diag([int(j in faceorbits[2]) for j in range(20)])
W=D_a-D_b
H=np.column_stack((H3,H5))
Wd=H.T@W@H
K1=H3.T@D_a@H5;K2=H3.T@D_b@H5
print('chirality: diagonal3',np.linalg.norm(H3.T@W@H3),'diagonal5',np.linalg.norm(H5.T@W@H5),'opposite cross',np.linalg.norm(K1+K2))
Cdiag=np.diag([-1]*4+[1]*4)
print('chirality anticommutator norm',np.linalg.norm(Cdiag@Wd+Wd@Cdiag))
print('chiral eigenvalues',np.linalg.eigvalsh(Wd))
# check symbolic anti-commutation and exact-square
Ds1=diag(*[int(j in faceorbits[1]) for j in range(20)])
Ds2=diag(*[int(j in faceorbits[2]) for j in range(20)])
Ws=Ds1-Ds2
assert P3*Ws*P3==Matrix.zeros(20,20)
assert P5*Ws*P5==Matrix.zeros(20,20)
print('exact diagonal chirality blocks ZERO, offdiagonal projectors doubled')
# A5-equivalent *two-layer* composite. 6D cube interlayer has 4_3 no coupling and 4_5 -2 isometry;
# identify the 4_5 frames across layers and orient the A4 selector coherently. This last identification is conditional.
Delta=3/20-(80/81)*np.pi/(13*phi)
Lh=np.diag([3.]*4+[5.]*4)
layercross=np.diag([0.]*4+[-2.]*4)
Wloc=H.T@W@H
H16=np.block([[Lh+Delta*Wloc,layercross],[layercross,Lh+Delta*Wloc]])
evals=np.sort(np.linalg.eigvalsh(H16))
expected=[]
for k2,mult in [(3/5,1),(1/15,3)]:
 levels=[3-Delta*np.sqrt(k2),3+Delta*np.sqrt(k2),5-np.sqrt(4+Delta*Delta*k2),5+np.sqrt(4+Delta*Delta*k2)]
 expected+= [v for v in levels for _ in range(mult)]
expected=np.sort(expected)
print('combined 16D eigen residual',np.max(np.abs(evals-expected)))
print('combined 16D full eigenvalues',np.round(evals,12))
print('hypercube alone hidden evalues', [3]*12+[7]*4)
print('linear 3+/- split singlet',Delta*np.sqrt(3/5),'triplet',Delta/np.sqrt(15),'3-to-1 ratio',np.sqrt((3/5)/(1/15)))
assert np.max(np.abs(evals-expected))<1e-12

result={
 'scope':'Exact finite quaternion, graph incidence and representation theorem. Resonant two-layer H16 is a conditional coherent alignment of two independently recovered native operators, not the selected physical URT/H64 transfer.',
 'cosets_24cell':5,'quaternion_600cell_vertices':120,'tetrahedral_rotation_group_order':12,
 'tetrahedral_face_orbit_sizes':[len(o) for o in faceorbits],
 'hidden_laplacian_spectrum':([3.]*4+[5.]*4),
 'quadratic_mixing_singular_values':[float(np.sqrt(3/20))]+[float(1/np.sqrt(60))]*3,
 'chiral_difference_singular_values':[float(np.sqrt(3/5))]+[float(1/np.sqrt(15))]*3,
 'chirality_block_anticonmutator':float(np.linalg.norm(Cdiag@Wd+Wd@Cdiag)),
 'exact_projector_squared_eigenvalues':['3/20']+['1/60']*3,
 'exact_hidden_compression_eig_formula':['(22-2sqrt6)/5','(22+2sqrt6)/5','(62-2sqrt61)/15 (x3)','(62+2sqrt61)/15 (x3)'],
 'Delta':Delta,
 'two_layer_resonance_singlet_delta':float(Delta*np.sqrt(3/5)),
 'two_layer_resonance_triplet_delta':float(Delta/np.sqrt(15)),
 'two_layer_exact_eigenvalues':evals.tolist(),
 'two_layer_spectrum_formula':['3 +/- Delta sqrt(3/5)','5 +/- sqrt(4+3Delta^2/5)','3 +/- Delta/sqrt(15) (x3)','5 +/- sqrt(4+Delta^2/15) (x3)'],
 'full_two_layer_direct_vs_formula_max_error':float(np.max(np.abs(evals-expected)))
}
(Path(__file__).resolve().parent/'cross_dim_operator_results.json').write_text(json.dumps(result,indent=2)+'\n')
