import runpy,contextlib,io,numpy as np
from pathlib import Path
from scipy.linalg import null_space,expm
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'history_positive_transfer.py'))
W=r['W'];I=np.eye(8);Ws=r['Ws']; T3=r['T'][3]
A=np.concatenate([np.kron(w.T,I)-np.kron(I,w) for w in Ws],axis=0)
C=null_space(A,rcond=1e-12)
print('CENTRAL DIM',C.shape[1]);Y=C[:,0].reshape(8,8,order='F');Y=(Y+Y.T)/2; Y-=np.trace(Y)/8*I
lam,U=np.linalg.eigh(Y)
print('central traceless eig',np.round(lam,12))
assert abs(lam[0]-lam[3])<1e-12 and abs(lam[4]-lam[-1])<1e-12
for k in [0,1]:
 E=U[:,4*k:4*(k+1)]
 S0=E.T@Ws[0]@E; val,V=np.linalg.eigh(S0)
 val3=val[:3] if np.max(np.abs(np.diff(val[:3])))<1e-12 else val[1:]
 uniq,ct=np.unique(np.round(val,9),return_counts=True)
 print('CENTER',k,'W0 spec',val,'list',list(zip(uniq,ct)))
 if abs(val[1]-val[0])<1e-10 and abs(val[2]-val[0])<1e-10:trip=V[:,:3]
 elif abs(val[3]-val[1])<1e-10 and abs(val[2]-val[1])<1e-10:trip=V[:,1:]
 else:
  print('not 1+3 block, cannot identify triplet');continue
 P=E@trip;w3=P.T@T3@P
 print('QUARTET T3 spectrum',np.round(np.linalg.eigvalsh(E.T@T3@E),9),'triplet projected T3',np.round(np.linalg.eigvalsh(w3),9))
 print('noncommutation W0,T3',np.linalg.norm(S0@(E.T@T3@E)-(E.T@T3@E)@S0))
