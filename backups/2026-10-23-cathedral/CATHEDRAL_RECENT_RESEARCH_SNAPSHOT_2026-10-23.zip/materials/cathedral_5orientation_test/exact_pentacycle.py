import runpy,io,contextlib,json
from pathlib import Path
import sympy as sp
import numpy as np
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
B=sp.Matrix([[int(round(x)) for x in row] for row in r['B']])
P=sp.eye(20)-B.T*(B*B.T).inv()*B
orb=r['small'];fm=r['face_perm'];rep=[x[0] for x in r['cosets']]
W=[]
for k in rep:
 u=fm(k);s0={u[j] for j in orb[0]};s1={u[j] for j in orb[1]}
 D=sp.diag(*[int(j in s0)-int(j in s1) for j in range(20)])
 W.append(P*D*P)
assert sum(W,sp.zeros(20))==sp.zeros(20)
order=[0,1,3,2,4]
Z=[W[k] for k in order]
G=-sp.Rational(1,2)*sum((Z[i]*Z[j]-Z[j]*Z[i] for i in range(5) for j in range(i)),sp.zeros(20))
tr2=sp.trace(G*G);tr4=sp.trace(G*G*G*G)
poly=G**4+sp.Rational(1,18)*G*G+sp.Rational(1,6480)*P
print('EXACT trG2',tr2,'trG4',tr4,'polyZERO',poly==sp.zeros(20))
assert tr2==sp.Rational(-2,9)
assert tr4==sp.Rational(1,90)
assert poly==sp.zeros(20)
print('nonzero spectral phase coeff',sp.sqrt((5+2*sp.sqrt(5))/180),sp.sqrt((5-2*sp.sqrt(5))/180))
Delta=r['Delta']; a=float(sp.sqrt((5+2*sp.sqrt(5))/180));b=float(sp.sqrt((5-2*sp.sqrt(5))/180))
print('delta',Delta,'a,b',a,b,'ratio',a/b,'phi^3',r['phi']**3,'phase shifts',a*Delta**2,b*Delta**2)
res={'trace_G_squared_exact':str(tr2),'trace_G_fourth_exact':str(tr4),'minimal_polynomial_on_hidden':'G^4+(1/18)G^2+(1/6480)I8=0','exact_minpoly_residual_zero':True,'leading_phases_abs':[b*Delta**2,a*Delta**2],'leading_phase_ratio':a/b}
(p/'exact_pentacycle_results.json').write_text(json.dumps(res,indent=2)+'\n')
