import runpy,io,contextlib,sympy as sp
from pathlib import Path
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
B=sp.Matrix([[int(round(x)) for x in row] for row in r['B']]); R=sp.Matrix.hstack(*B.nullspace());metric=R.T*R;invmetric=metric.inv();I=sp.eye(8)
Ws=[]
for k,c in r['cosets']:
 u=r['face_perm'](k);a={u[j] for j in r['small'][0]};b={u[j] for j in r['small'][1]}
 D=sp.diag(*[int(j in a)-int(j in b) for j in range(20)])
 Ws.append(invmetric*(R.T*D*R))
assert sum(Ws,sp.zeros(8))==sp.zeros(8)
W=Ws[0];order=[0,1,3,2,4];coef=[I,sp.zeros(8),sp.zeros(8),sp.zeros(8)]
for k in order:
 M=Ws[k];powers=[I,-M,M*M/2,-M*M*M/6]
 coef=[sum((powers[j]*coef[n-j] for j in range(n+1)),sp.zeros(8)) for n in range(4)]
assert coef[1]==sp.zeros(8)
B3=coef[3];T3=B3+invmetric*B3.T*metric
x=sp.symbols('x')
print('T3 charpoly:',sp.factor(T3.charpoly(x).as_expr()))
a2=sp.Rational(3,5);b2=sp.Rational(1,15); b=sp.sqrt(b2);d=sp.sqrt(sp.Rational(1,135)); c2=sp.Rational(2,135)
Ptr=(a2*I-W*W)/(a2-b2)
assert Ptr*Ptr==Ptr
A=Ptr*T3*Ptr
print('all-triplet projected T3 charpoly',sp.factor(A.charpoly(x).as_expr(),extension=sp.sqrt(5)))
for s in [1,-1]:
 Q=(Ptr+s*W*Ptr/b)/2
 assert (Q*Q-Q).applyfunc(sp.simplify)==sp.zeros(8)
 mat=Q*T3*Q
 print('s',s,'rank',Q.rank(),'trace',sp.simplify(sp.trace(mat)),'trace2',sp.simplify(sp.trace(mat*mat)))
 expr=mat**3-s*d*mat**2-c2*mat+s*c2*d*Q
 print('exact projected cubic holds?',expr.applyfunc(sp.simplify)==sp.zeros(8))
 assert expr.applyfunc(sp.simplify)==sp.zeros(8)
print('EXACT √2 TRIPLET PROOF PASSED')
