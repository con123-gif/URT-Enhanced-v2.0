import runpy,io,contextlib,numpy as np,json
from itertools import combinations
from pathlib import Path
from scipy.linalg import expm
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'structure_followup.py'))
Ws=r['Ws'];phi=r['R']['phi'];Delta=r['Delta'];I=np.eye(8)
kt=Ws[0][:4,4:]
l,V=np.linalg.eigh(kt@kt.T)
print('W0 square first4',l)
trip=V[:,:3]; F=np.vstack((trip,np.zeros((4,3))))
assert np.linalg.norm(F.T@F-I[:3,:3])<1e-12

def coeff3(order):
 c=[I.copy(),np.zeros((8,8)),np.zeros((8,8)),np.zeros((8,8))]
 for idx in order:
  w=Ws[idx]; a=[I,-w,w@w/2,-w@w@w/6]
  c=[sum((a[k]@c[n-k] for k in range(n+1)),np.zeros((8,8))) for n in range(4)]
 return c[3]+c[3].T
cycles=[]
for perm,g in r['cycs']:
 order=[0]
 for t in range(4):order.append(perm[order[-1]])
 cycles.append(order)
target=np.sort(np.r_[[-x for x in [np.sqrt(2*(3-np.sqrt(5))/675),np.sqrt(2*(3+np.sqrt(5))/675),np.sqrt(10*(3-np.sqrt(5))/675),np.sqrt(10*(3+np.sqrt(5))/675)]],[np.sqrt(2*(3-np.sqrt(5))/675),np.sqrt(2*(3+np.sqrt(5))/675),np.sqrt(10*(3-np.sqrt(5))/675),np.sqrt(10*(3+np.sqrt(5))/675)]] )
target_g=np.sort(np.r_[[-np.sqrt((5+2*np.sqrt(5))/180),-np.sqrt((5-2*np.sqrt(5))/180)],[np.sqrt((5+2*np.sqrt(5))/180),np.sqrt((5-2*np.sqrt(5))/180)]])
errs=[];trip_eig=[]
for order in cycles:
 t=coeff3(order)
 err=np.max(np.abs(np.linalg.eigvalsh(t)-target));errs.append(err)
 tripvals=np.linalg.eigvalsh(F.T@t@F);trip_eig.append(tripvals)
print('24 cycles tested: max exact T3 golden err',max(errs))
print('reference triplet T3 projected eigen',trip_eig[0])
print('All projected T3 triplet eigenvalues are zero to roundoff; Koide of zero shifts undefined')
print('distinct triplet fraction',sum(np.min(np.diff(x))>1e-5 for x in trip_eig))
print('first 6 cycles triplet',*[np.round(x,8) for x in trip_eig[:6]],sep='\n')
# Compare actual B.TB/g^3 in reference orientation for projected triplet
for g in [Delta,.02,.05]:
 B=I.copy()
 for j in cycles[0]:B=expm(-g*Ws[j])@B
 Q=F.T@B.T@B@F
 e=np.linalg.eigvalsh(Q)
 print('g',g,'native triplet eigen',e,'deviation',e-1,'Q on positive eigen as root masses',e.sum()**0 if False else sum(e**2)/(sum(e)**2))
results={'cycle_count':len(cycles),'max_exact_T3_golden_deviation':float(max(errs)),'reference_triplet_T3_eigenvalues':trip_eig[0].tolist(),'triplet_distinct_cycles':int(sum(np.min(np.diff(x))>1e-5 for x in trip_eig)),}
(p/'five_cycle_mass_projection_results.json').write_text(json.dumps(results,indent=2)+'\n')
