import runpy,io,contextlib,sympy as sp
from pathlib import Path
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'exact_8d_triplet.py'))
W=r['Ws'];I=sp.eye(8)
L=sp.Matrix.vstack(*[sp.kronecker_product(w.T,I)-sp.kronecker_product(I,w) for w in W])
ns=L.nullspace()
print('exact centralizer dimension',len(ns))
assert len(ns)==2
for k,b in enumerate(ns):
 X=sp.Matrix(8,8,lambda i,j:b[j*8+i]);print('central',k,'trace',sp.trace(X),'antisym',X-X.T)
 if sp.trace(X)!=0 and X != sp.eye(8): pass
# two dim central; choose non-scalar then subtract trace and square
X=sp.Matrix(8,8,lambda i,j:ns[0][j*8+i]);
if X==sp.trace(X)/8*I:
 X=sp.Matrix(8,8,lambda i,j:ns[1][j*8+i]);
C=X-sp.trace(X)/8*I
print('trace zero',sp.trace(C),'trC2',sp.trace(C*C),'C2scalar?',C*C==sp.trace(C*C)/8*I)
print('eigen mult',C.eigenvals())
assert C*C==sp.trace(C*C)/8*I
