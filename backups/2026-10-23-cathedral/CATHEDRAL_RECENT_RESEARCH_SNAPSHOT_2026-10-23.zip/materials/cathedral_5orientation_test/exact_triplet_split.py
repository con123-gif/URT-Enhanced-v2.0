import runpy,io,contextlib
from pathlib import Path
import sympy as sp
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'exact_positive_history.py'))
# variables exact_rational: P projection onto 8 hidden, W0, T3 from previous source
P=r['P']; W=r['W'][0]; T=r['T3'];I=sp.eye(20)
a2=sp.Rational(3,5);b2=sp.Rational(1,15);b=sp.sqrt(b2);c2=sp.Rational(2,135)
Ptr=sp.simplify((a2*P-W*W)/(a2-b2))
assert Ptr*Ptr==Ptr and sp.trace(Ptr)==6
for s in (1,-1):
 Q=sp.simplify((Ptr+s*W*Ptr/b)/2)
 print('s',s,'rank',Q.rank(),'trace',sp.trace(Q),'idempotent',Q*Q==Q)
 A=Q*T*Q
 print('Tr A',sp.simplify(sp.trace(A)),'Tr A²',sp.simplify(sp.trace(A*A)),'Tr A³',sp.simplify(sp.trace(A**3)))
 # roots (-sqrt(2/135), s*b, +sqrt(2/135)); b=1/sqrt135? wait b=1/sqrt15, correction coeff d=1/(3 sqrt15)
 d=sp.sqrt(sp.Rational(1,135))
 poly=A**3-s*d*A**2-c2*A+s*c2*d*Q
 print('poly cubic exact',poly==sp.zeros(20),'normresid',len([z for z in poly if z!=0]))
 assert poly==sp.zeros(20)
print('success')
