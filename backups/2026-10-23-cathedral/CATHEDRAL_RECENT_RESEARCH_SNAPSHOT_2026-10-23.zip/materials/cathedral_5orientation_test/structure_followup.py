import runpy, contextlib, io, numpy as np
from scipy.linalg import null_space
from pathlib import Path
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):R=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
Ws=R['Ws'];q=R['q'];cosets=R['cosets'];ids=R['ids'];mul=R['mul'];indx=R['indx'];h=R['h']
# simultaneous commutant: [X,Wi]=0 linear equations in 64 unknowns
I=np.eye(8)
A=np.concatenate([np.kron(w.T,I)-np.kron(I,w) for w in Ws],axis=0)
Z=null_space(A,rcond=1e-11)
print('CENTRALIZER dimension',Z.shape)
for i in range(Z.shape[1]):
 X=Z[:,i].reshape(8,8,order='F'); tr=np.trace(X)
 print('central basis',i,'trace',tr,'symmetric',np.linalg.norm(X-X.T),'skew',np.linalg.norm(X+X.T),'eig',np.round(np.linalg.eigvals(X),4))
# Gram quadrature eigen of individual Ws and pairwise products
print('eigs W',np.round(np.linalg.eigvalsh(Ws[0]),8))
print('comm eigenpair0 1',np.round(np.linalg.eigvalsh(1j*(Ws[0]@Ws[1]-Ws[1]@Ws[0])),8))
# quaternion left multiplication induces permutation of five cosets
coset_by_elem={k:i for i,(rep,C) in enumerate(cosets) for k in C}
def perm5(i):return tuple(coset_by_elem[indx(mul(q[i],q[rep]))] for rep,C in cosets)
def cyc5(p):
 if sorted(p)!=list(range(5)):return False
 x=0;seen=set()
 for _ in range(5):
  if x in seen:return False
  seen.add(x);x=p[x]
 return x==0 and len(seen)==5

perms={perm5(i):i for i in range(120)}
cycs=[(k,v) for k,v in perms.items() if cyc5(k)]
print('unique 5cycles',len(cycs))
from scipy.linalg import expm
Delta=R['Delta']
for j,(perm,g) in enumerate(cycs[:12]):
 order=[0];
 for z in range(4):order.append(perm[order[-1]])
 W=Ws[order]
 G=-.5*sum(W[i]@W[j]-W[j]@W[i] for i in range(5) for j in range(i))
 vals=np.sort(np.linalg.eigvalsh(1j*G))
 hol=np.eye(8,dtype=complex)
 for w in W:hol=expm(1j*Delta*w)@hol
 ph=np.sort(np.angle(np.linalg.eigvals(hol)))
 print('CYCLE',j,'rep',g,'order',order,'G eval',np.round(vals,9),'phase',np.round(ph,11),'numerical ratio at delta^2',np.round(ph/(Delta**2),7))
