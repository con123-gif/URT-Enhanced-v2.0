"""Conditional composition of independent cube Lhid interlayer transfer and five 600-cell tetra-history gates."""
import runpy,io,contextlib,json,math
from pathlib import Path
import numpy as np
from scipy.linalg import expm, block_diag
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
Ws=r['Ws'];phi=r['phi'];Delta=r['Delta'];beta=-math.log(Delta)
order=[0,1,3,2,4];L=np.diag([3.]*4+[5.]*4);C=np.diag([0.]*4+[-2.]*4)
H0=np.block([[L,C],[C,L]])
vals,vec=np.linalg.eigh(H0)
assert np.allclose(vals,[3]*12+[7]*4)
T0=vec@np.diag(np.exp(-beta*(vals-3)))@vec.T
results=[]
for g in [0,Delta/2,Delta,2*Delta,.05,.1,.3,1.0]:
 B=np.eye(8)
 for i in order:B=expm(-g*Ws[i])@B
 S=block_diag(B,B)
 T=S.T@T0@S
 ev=np.sort(np.linalg.eigvalsh(T))[::-1]
 assert ev[-1]>0
 E=3-np.log(ev)/beta
 low=E[:12]
 print('g=',g,'near3 minmax',np.min(low),np.max(low),'spread',np.ptp(low),'mean',np.mean(low),'higher4',np.round(E[12:],8))
 results.append({'g':float(g),'near3_levels':low.tolist(),'near3_spread':float(np.ptp(low)),'mean':float(np.mean(low)),'upper4_levels':E[12:].tolist()})
(p/'full_16d_positive_transfer_results.json').write_text(json.dumps({'scope':'conditional multiplication of two independently fixed positive transfers; g=Delta and intergeometry registration not derived','beta':beta,'results':results},indent=2))
