#!/usr/bin/env python3
"""Independent Schlaefli H4 -> H3 -> Cathedral 13/8 and 64-subset audit.
Dependencies: numpy, networkx. Does not access GitHub, use empirical physics,
or assume 600-cell face states are automatically in the 120-vertex Hilbert space.
"""
import itertools, json, math
from collections import Counter
from pathlib import Path
import numpy as np
import networkx as nx

phi=(1+math.sqrt(5))/2
p=[]
for i in range(4):
    for sign in (-1,1):
        a=np.zeros(4);a[i]=sign;p.append(tuple(a))
for s in itertools.product((-1,1),repeat=4):p.append(tuple(x/2 for x in s))
seed=(0,1/2,phi/2,1/(2*phi))
def parity(t):return sum(t[i]>t[j] for i in range(4) for j in range(i+1,4))%2
for t in itertools.permutations(range(4)):
    if parity(t):continue
    base=np.array(seed)[list(t)]
    for s in itertools.product((-1,1),repeat=3):
        a=base.copy();n=np.flatnonzero(a);a[n]*=np.array(s);p.append(tuple(a))
vertices=np.array(p,float)
assert vertices.shape==(120,4) and len(set(p))==120
assert np.max(abs(np.linalg.norm(vertices,axis=1)-1))<1e-12
A600=np.isclose(vertices@vertices.T,phi/2,atol=1e-10).astype(int)
np.fill_diagonal(A600,0)
assert int(A600.sum()//2)==720 and np.all(A600.sum(axis=1)==12)

# At the vertex (1,0,0,0), its twelve nearest neighbours constitute an ico.
central=int(np.flatnonzero(np.linalg.norm(vertices-np.array([1,0,0,0]),axis=1)<1e-12)[0])
idx=np.flatnonzero(A600[central]); assert len(idx)==12
icosa=A600[np.ix_(idx,idx)]
assert int(icosa.sum()//2)==30 and nx.is_isomorphic(nx.from_numpy_array(icosa),nx.icosahedral_graph())
faces=sorted(t for t in itertools.combinations(range(12),3) if all(icosa[a,b] for a,b in itertools.combinations(t,2)))
assert len(faces)==20
B=np.array([[int(i in t) for t in faces] for i in range(12)],dtype=float)
assert np.array_equal(B@B.T,5*np.eye(12)+2*icosa)
assert np.linalg.matrix_rank(B)==12

dual=nx.Graph();dual.add_nodes_from(range(20))
for i,j in itertools.combinations(range(20),2):
    if len(set(faces[i]) & set(faces[j]))==2:dual.add_edge(i,j)
assert dual.number_of_edges()==30 and nx.is_isomorphic(dual,nx.dodecahedral_graph())
L20=nx.laplacian_matrix(dual,nodelist=range(20)).toarray().astype(float)
vals,vectors=np.linalg.eigh(B.T@B)
K=vectors[:,:8]
assert np.max(abs(vals[:8]))<1e-12
hidden=np.linalg.eigvalsh(K.T@L20@K)
assert np.allclose(hidden,[3]*4+[5]*4,atol=1e-12)
invariance=float(np.linalg.norm((np.eye(20)-K@K.T)@L20@K))
assert invariance<1e-12

# Literal 13-vertex induced star within 120 vertex graph.
star=[central]+list(idx); As=A600[np.ix_(star,star)]
assert int(As.sum()//2)==42
Ls=np.diag(As.sum(axis=1))-As
spectrum=np.linalg.eigvalsh(Ls)
expected=np.array([0]+[6-math.sqrt(5)]*3+[7]*5+[6+math.sqrt(5)]*3+[13])
assert np.allclose(spectrum,expected,atol=1e-12)

# The exactly-64 golden-shell subset is NOT the six-dimensional cube graph.
q=np.round(vertices@vertices[central],10)
layercounts=sorted(((float(k),int(v)) for k,v in Counter(q).items()),reverse=True)
selection=np.flatnonzero(np.isclose(np.abs(q),phi/2,atol=1e-9)|np.isclose(np.abs(q),.5,atol=1e-9))
assert len(selection)==64
A64=A600[np.ix_(selection,selection)]
S=nx.from_numpy_array(A64)
components=sorted([len(x) for x in nx.connected_components(S)])
deg_counts={str(int(k)):int(v) for k,v in zip(*np.unique(A64.sum(axis=1),return_counts=True))}
assert components==[32,32] and deg_counts=={'6':40,'10':24} and S.number_of_edges()==240
cube=nx.hypercube_graph(6)
assert cube.number_of_nodes()==64 and cube.number_of_edges()==192 and nx.is_connected(cube)

out={
 'phi':phi,'polytope_600_cell':{'vertices':120,'edges':720,'regular_degree':12,'radial_layers_inner_product_and_count':layercounts},
 'vertex_star_13':{'vertices':13,'edges':42,'shell_icosa_edges':30,'laplacian_eigenvalues':spectrum.tolist(),'expected_laplacian_eigenvalues':expected.tolist(), 'residual_max':float(np.max(np.abs(spectrum-expected)))},
 'incidence_icosa_vertices_to_triangular_faces':{'shape':[12,20],'rank':12,'kernel_dimension':8,'gram_identity_error':float(np.max(abs(B@B.T-(5*np.eye(12)+2*icosa)))),'dual_face_graph_is_dodecahedron':True,'hidden_dodecahedral_Laplacian_eigenvalues':hidden.tolist(),'hidden_invariance_leakage':invariance},
 'golden_shell_64_subgraph':{'selected_orbit_sizes':[12,20,20,12],'vertices':64,'edges':240,'components':components,'degree_counts':deg_counts,'is_6D_cube_graph':False},
 'six_dimensional_hypercube_graph':{'vertices':cube.number_of_nodes(),'edges':cube.number_of_edges(),'connected':True,'regular_degree':6},
 'scope':'Local 13/8 geometric incidence derivation at any 600-cell vertex. Does not assert that the 8 face-mode states are automatically 120-vertex graph eigenstates; nor that the 64 selected 600-cell vertices have cube graph dynamics.'
}
path=Path(__file__).with_name('600_cell_cathedral_local_audit_results.json');path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
