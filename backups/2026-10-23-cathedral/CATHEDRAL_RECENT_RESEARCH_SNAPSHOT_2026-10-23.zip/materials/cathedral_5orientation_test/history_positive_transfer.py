from pathlib import Path
import runpy,io,contextlib,json,numpy as np
from scipy.linalg import expm,svdvals
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
Ws=r['Ws'];phi=r['phi'];Delta=r['Delta'];order=[0,1,3,2,4];W=Ws[order]
I=np.eye(8)
# Taylor coefficients B = prod exp(-gW), T=B.T@B with natural chronological order
D=5
c=[I]+[np.zeros((8,8)) for j in range(D)]
for w in W:
 powers=[I]
 for k in range(1,D+1):powers.append(powers[-1]@(-w)/k)
 new=[]
 for n in range(D+1):new.append(sum((powers[k]@c[n-k] for k in range(n+1)),np.zeros((8,8))))
 c=new
T=[]
for n in range(D+1):T.append(sum((c[k].T@c[n-k] for k in range(n+1)),np.zeros((8,8))))
print('Taylor norm B1 B2 B3',*[np.linalg.norm(c[k]) for k in (1,2,3)])
print('T3 diag block norm',np.linalg.norm(T[3][:4,:4]),np.linalg.norm(T[3][4:,4:]),'offdiag',np.linalg.norm(T[3][:4,4:]))
print('T coefficients norms 1-5',*[np.linalg.norm(T[k]) for k in range(1,D+1)])
for i in [2,3,4,5]:print('T coefficient',i,'eigen',np.round(np.linalg.eigvalsh(T[i]),10))
for scale in [Delta/2,Delta,2*Delta,.01,.03,.1]:
 b=I.copy()
 for w in W:b=expm(-scale*w)@b
 t=b.T@b
 eig=np.sort(np.linalg.eigvalsh(t))
 C=sum(scale**n*T[n] for n in range(D+1))
 print('d',scale,'log singular vals',np.round(np.log(np.sqrt(eig)),12),'TT min max',eig[0],eig[-1], 'T-I F',np.linalg.norm(t-I),'expansion residual',np.linalg.norm(t-C))
# compare reversals via B.T symmetry
bs=[]
for seq in [order,list(reversed(order))]:
 b=I.copy()
 for i in seq:b=expm(-.1*Ws[i])@b
 bs.append(b)
print('time-reverse B ~ B.T error',np.linalg.norm(bs[1]-bs[0].T))
print('T spectra mirror',np.round(np.linalg.eigvalsh(bs[0].T@bs[0]),10),np.round(np.linalg.eigvalsh(bs[1].T@bs[1]),10))
result={'delta':float(Delta),'taylor_norms_T':[float(np.linalg.norm(k)) for k in T],'T3_eigenvalues':np.linalg.eigvalsh(T[3]).tolist(),'T4_eigenvalues':np.linalg.eigvalsh(T[4]).tolist(),'T5_eigenvalues':np.linalg.eigvalsh(T[5]).tolist()}
(p/'history_positive_transfer_results.json').write_text(json.dumps(result,indent=2)+'\n')
