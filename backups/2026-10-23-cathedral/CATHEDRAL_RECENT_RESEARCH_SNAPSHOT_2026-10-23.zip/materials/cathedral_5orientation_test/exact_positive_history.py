import runpy,io,contextlib
from pathlib import Path
import sympy as sp
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):r=runpy.run_path(str(p/'five_tetrahedral_orientations.py'))
B=sp.Matrix([[int(round(x)) for x in row] for row in r['B']]);P=sp.eye(20)-B.T*(B*B.T).inv()*B
W=[]
for k,c in r['cosets']:
 u=r['face_perm'](k);s0={u[j] for j in r['small'][0]};s1={u[j] for j in r['small'][1]}
 D=sp.diag(*[int(j in s0)-int(j in s1) for j in range(20)])
 W.append(P*D*P)
order=[0,1,3,2,4]
# B=prod exp(-g W), coefficients to order 3
D=3
coeff=[P]+[sp.zeros(20) for j in range(D)]
for k in order:
 w=W[k];powers=[P,-w,w*w/2,-w*w*w/6]
 new=[]
 for n in range(D+1):new.append(sum((powers[j]*coeff[n-j] for j in range(n+1)),sp.zeros(20)))
 coeff=new
T3=coeff[3]+coeff[3].T # B1 zero
print('Coeff B1 exactly zero',coeff[1]==sp.zeros(20))
T2=coeff[2]+coeff[2].T+coeff[1].T*coeff[1]
print('Coeff T2 exactly zero',T2==sp.zeros(20))
print('T3 trace2',sp.trace(T3*T3))
print('T3 trace4',sp.trace(T3**4))
print('T3 trace6',sp.trace(T3**6))
# expected eigen ± sqrt[2(3±sqrt5)/675], sqrt[10(3±sqrt5)/675]
x=sp.symbols('x');v=sp.sqrt(5)
lam2=[2*(3-v)/675,2*(3+v)/675,10*(3-v)/675,10*(3+v)/675]
f=sp.expand(sp.prod(x**2-j for j in lam2));print('exact polynomial',sp.factor(f));
fpoly=sp.Poly(f,x)
M=sum((c*(T3**int(m[0])) if m[0]>0 else c*P for m,c in fpoly.terms()),sp.zeros(20))
print('T3 satisfies exact polynomial',M==sp.zeros(20))
print('exact T3 on complement',T3*(sp.eye(20)-P)==sp.zeros(20))
assert M==sp.zeros(20)
assert sp.trace(T3*T3)==sp.Rational(16,75)
print('success')
