"""Exact-structure numerical audit of the Cathedral 13-mode QR proposal.

Requires numpy and networkx. Makes no fits to experimental masses.

This is a test of the mathematical transform and its relation to a centred
icosahedral graph, not a claimed derivation of a Standard Model mass operator.
The graph's ordering of the twelve shell sites is a convention, not physics.
"""
import numpy as np
import networkx as nx

N = 13
PHI = (1 + np.sqrt(5)) / 2
DELTA_STAR = 80 * np.pi / (81 * N * PHI)
DELTA_CLASSIC = 3 / 20


def qr_positive(U):
    """Householder QR with nonnegative-real diagonal entries in R."""
    Q, R = np.linalg.qr(U)
    phases = np.diag(R) / np.abs(np.diag(R))
    return Q @ np.diag(phases), np.diag(phases.conj()) @ R


def raw_matrix(delta):
    n = np.arange(N)[:, None]
    k = np.arange(N)[None, :]
    return np.exp(2j * np.pi * delta * n * k / N)


def exact_gram(delta):
    j = np.arange(N)[:, None]
    k = np.arange(N)[None, :]
    m = k - j
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.sin(np.pi * delta * m) / np.sin(np.pi * delta * m / N)
    ratio = np.where(m == 0, N, ratio)
    return np.exp(12j * np.pi * delta * m / N) * ratio


def phase_diagonal():
    low = np.exp(0.5j * np.pi * np.arange(4))
    high = np.exp(2j * np.pi * (np.arange(4, N) - 4) / 5)
    return np.diag(np.r_[low, high])


def centred_icosahedron_laplacian():
    # Hub labelled 0; shells 1..12 follow the networkx icosahedron numbering.
    A = np.zeros((N, N))
    A[0, 1:] = 1
    A[1:, 0] = 1
    A[1:, 1:] = nx.to_numpy_array(nx.icosahedral_graph(), nodelist=range(12))
    return np.diag(A.sum(axis=1)) - A


def schur_effective(M, z=14):
    A, B = M[:4, :4], M[:4, 4:]
    E = M[4:, 4:]
    return A + B @ np.linalg.solve(z * np.eye(9) - E, B.conj().T)



def symmetry_sector_check(L):
    """Find genuine orientation-preserving A5, K4 and C5 actions on the 13-cell."""
    shell_graph = nx.icosahedral_graph()
    eigvals, eigvecs = np.linalg.eigh(L)
    slow3 = eigvecs[:, 1:4]
    P4 = eigvecs[:, :4] @ eigvecs[:, :4].T
    P9 = np.eye(13) - P4
    rotations = []
    for mapping in nx.algorithms.isomorphism.GraphMatcher(shell_graph, shell_graph).isomorphisms_iter():
        perm = tuple(mapping[j] for j in range(12))
        R = np.zeros((13,13))
        R[0,0] = 1
        for j in range(12):
            R[perm[j]+1, j+1] = 1
        if np.linalg.det(slow3.T @ R @ slow3) < 0.5:
            continue
        composition = tuple(range(12))
        for order in range(1, 11):
            composition = tuple(perm[j] for j in composition)
            if composition == tuple(range(12)):
                break
        rotations.append((perm, R, order))
    from collections import Counter
    counts = Counter(order for _,_,order in rotations)
    assert counts == {1:1, 2:15, 3:20, 5:24}
    print("\nA5_rotation_orders", dict(sorted(counts.items())))

    compose = lambda p,q: tuple(p[j] for j in q)
    involutions = [(perm,R) for perm,R,order in rotations if order==2]
    for pa,Ra in involutions:
        for pb,Rb in involutions:
            if pa==pb or compose(pa,pb)!=compose(pb,pa):
                continue
            ranks4, ranks9 = [], []
            for sign1,sign2 in ((-1,-1),(-1,1),(1,-1),(1,1)):
                projector=((np.eye(13)+sign1*Ra)@(np.eye(13)+sign2*Rb))/4
                ranks4.append(int(round(np.trace(projector@P4).real)))
                ranks9.append(int(round(np.trace(projector@P9).real)))
            break
        else:
            continue
        break
    assert ranks4 == [1,1,1,1]
    assert sorted(ranks9)==[2,2,2,3]
    print("K4_coherent_character_ranks", ranks4)
    print("K4_exhaust_character_ranks", ranks9)

    R5=next(R for _,R,order in rotations if order==5)
    zeta=np.exp(2j*np.pi/5)
    def multiplicities(P):
        out=[]
        for a in range(5):
            Pa=sum(zeta**(-a*t)*np.linalg.matrix_power(R5,t) for t in range(5))/5
            out.append(int(round(np.trace(P@Pa).real)))
        return out
    m13, m4, m9 = [multiplicities(P) for P in (np.eye(13),P4,P9)]
    assert m13==[5,2,2,2,2]
    assert sorted(m4)==[0,0,1,1,2]
    assert sorted(m9)==[1,1,2,2,3]
    supplied_exponents=(np.arange(4,13)-4)%5
    supplied_counts=[int(np.count_nonzero(supplied_exponents==a)) for a in range(5)]
    assert sorted(supplied_counts) != sorted(m9)
    print("C5_full_multiplicities",m13)
    print("C5_coherent_multiplicities",m4)
    print("C5_exhaust_multiplicities",m9)
    print("Proposed_phi_exhaust_multiplicities",supplied_counts)
    print("PASS: genuine icosahedral C5 action is not unitarily equivalent to proposed exhaust phases")

def main():
    print("delta_star", format(DELTA_STAR, ".15f"))
    print("delta_classic", format(DELTA_CLASSIC, ".15f"))
    print("rail_gap", format(DELTA_CLASSIC - DELTA_STAR, ".15f"))
    L = centred_icosahedron_laplacian()
    evals, evects = np.linalg.eigh(L)
    expected = np.sort(np.r_[0, [6-np.sqrt(5)]*3, [7]*5, [6+np.sqrt(5)]*3, 13])
    np.testing.assert_allclose(evals, expected, atol=1e-12)
    Pcoh = evects[:, :4] @ evects[:, :4].conj().T
    D = phase_diagonal()
    print("L13_spectrum", np.round(evals, 9))

    for delta in (DELTA_STAR, DELTA_CLASSIC):
        U = raw_matrix(delta)
        Q, R = qr_positive(U)
        V = U @ D
        Qv = Q @ D
        Rv = D.conj().T @ R @ D
        G = U.conj().T @ U

        np.testing.assert_allclose(Q.conj().T @ Q, np.eye(N), atol=1e-12)
        np.testing.assert_allclose(U, Q @ R, atol=1e-12)
        np.testing.assert_allclose(G, exact_gram(delta), atol=1e-12)
        np.testing.assert_allclose(V, Qv @ Rv, atol=1e-12)
        np.testing.assert_allclose(np.imag(np.diag(Rv)), 0, atol=1e-12)

        # The Gram centre phase is an entirely removable vertex gauge.
        c = 12 * np.pi * delta / N
        C = np.diag(np.exp(1j * c * np.arange(N)))
        np.testing.assert_allclose(np.imag(C @ G @ C.conj().T), 0, atol=1e-12)

        # Physical eigenvalues and the full Schur poles do not change under D.
        H = Q.conj().T @ L @ Q
        Hv = D.conj().T @ H @ D
        S = schur_effective(H)
        Sv = schur_effective(Hv)
        gauge_error = np.linalg.norm(Sv-D[:4,:4].conj().T @ S @ D[:4,:4])
        assert gauge_error < 1e-12
        np.testing.assert_allclose(np.linalg.eigvalsh(Sv), np.linalg.eigvalsh(S), atol=1e-12)
        np.testing.assert_allclose(np.linalg.eigvalsh(H), evals, atol=1e-12)

        Pqr = Q[:,:4] @ Q[:,:4].conj().T
        overlap = np.trace(Pcoh @ Pqr).real
        B = H[:4,4:]
        print("\ndelta", format(delta, ".15f"))
        print("R00_to_R33", np.round(np.diag(R)[:4].real, 9))
        print("cond_U", f"{np.linalg.cond(U):.6e}")
        print("|G01|/13", f"{abs(G[0, 1])/13:.12f}")
        print("spectral_projector_overlap_of_rank4", f"{overlap:.12f}")
        print("offblock_norm_F", f"{np.linalg.norm(B):.12f}")
        print("schur_phase_conjugacy_error", f"{gauge_error:.6e}")
        print("schur_eigenvalues_z14_illustrative", np.round(np.linalg.eigvalsh(S),9))

        # At H=identity the extracted 3-mode spectrum is exactly degenerate,
        # even though R_11, R_22, R_33 are highly hierarchical.
        Ieff = schur_effective(np.eye(N, dtype=complex))
        np.testing.assert_allclose(Ieff, np.eye(4), atol=1e-12)
        identity_koide_triplet = 3 / 3**2
        assert identity_koide_triplet == 1/3

    symmetry_sector_check(L)
    print("\nPASS: all phase-gauge, Gram, spectrum and projector tests")
    print("NOTE: projector overlap depends on arbitrary shell-site numbering;")
    print("      it must not be interpreted as a physical model prediction.")

if __name__ == "__main__":
    main()
