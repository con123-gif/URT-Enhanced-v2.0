# Newton's Cathedral / URT — Chat-first continuity restoration
**Snapshot: 18 October 2026. Scope: prior ChatGPT conversation history and original already-recovered local calculations. No repository access or repository updates in this work.**

## Precedence contract
1. Recovered chronological conversations and their corrections outrank later isolated assistant summaries or simplified tests.
2. Earlier mathematically closed results remain closed unless a later calculation directly contradicts the *same* hypotheses and operator. A failed alternative surrogate is not a contradiction.
3. A source-level identity, a response-model identity, and an independently predictive physical observable are three different levels of proof.
4. Preserve URT as history-selection principle, *not* identical to the positive transfer itself: raw chaos → selected histories → positive T=B†B → rho_* and BKM geometry → matter/forces → physical correlators/spacetime.
5. No fitting, no empirical normalization inserted by hand; retain source and date provenance for any empirical comparison.

## CLOSED AND FROZEN — exact internal finite mathematics
- Canonical parameters: phi=(1+sqrt5)/2, kappa_spiral=pi/e, alpha_URT=phi^-2, spiral increment 2pi/phi^2; D=3, N=13, gamma=1/81, rail d_*=80pi/(1053phi), classical rail d_cl=3/20, gap Delta=0.002489189840420... .
- Canonical 13-cell icosahedral symmetry representation 1⊕3⊕3'⊕5, and hidden 4_3⊕4_5 with KO-6 and the typed Hermitian carrier. The actual centred-icosahedron has 42 edges: do not substitute the legacy 36-edge surrogate for its full representation physics.
- Master selected response state rho_*=(I4⊕Delta² I4)/[4(1+Delta²)]; p5=Delta²/(1+Delta²), hidden entropy and BKM variation as algebraic identities.
- Original symmetry/hidden-sector chirality and noncommuting finite transfer identities, where certified, are internal mathematical closures; whether their continuum response is experimentally Einstein/Yang-Mills remains separate.
- The **September 6 v35 wall-current finite response calculation** from earlier chats and the saved `Newton_Cathedral_URT_Full_Paper_v35` / `Cathedral_Live_State_v59`: Y24=U_L M is the endpoint Schur complement of locked L=13 wall, U_L=Y24 M^-1 with unitarity error <3e-12. Define H_response=sqrt(D48²), T_response=exp(-H_response)>0. CKM and PMNS are evaluated as free charged-current Lehmann residues U_u†J_ud U_d and U_e†J_eν U_ν. They reproduce already *frozen response matrices* at maximum complex residual 2.22e-16 and 1.11e-16, respectively. Internal Jarlskog invariants J_CKM=3.141364407663606e-5, J_PMNS=-0.03235946792546523. The data predated the freeze; the agreement of the residue representation with its preconstructed matrices is not an independent blind prediction.

## CLOSED MATHEMATICALLY / PHYSICAL IDENTIFICATION PENDING
- Exact original H64→H13⊕H51 Feshbach and source-defined native rank-one/14→4 charged witness. The October 17-18 source calculation gives original electron conditional three pole eigenvalues (0.11691800343, 1.04425714086, 2.34366594047) and native root-Koide Q≈0.537036846. **These are poles of a particular positive conditional history operator, not yet experimentally identified Dirac-particle poles.**
- Exact hidden 4_5 rail parity generates O(Delta²) pole displacement and Δ-dependent spectral response. The earlier computed phase perturbation −5.1911192e−7 rad acts around the source-derived spectral parameter 0.4274263, not around 2/9. Does not supersede Y24/v35.
- Original 18D signed-history polar transport has identity holonomy at the selected source and vanishing first derivative, but some history fluctuations yield second-order, orientation-carrying phases. Converting the selected photon/current history to a physical charged-lepton pole remains an identification requirement.
- v35 positive wall-current correlators are explicitly **free/finite-cutoff**. The interacting gauge-projected many-body current correlator, gauge Ward identities, continuum/universality and prospective blind measurements still need independent establishment.
- Newton Scale Platonic finite spectral theorems and possible sub-Planck response remain distinct: finite geometry is not by itself a measured UV physical law.

## DIAGNOSTIC ONLY; NOT CANONICAL FAILURE
- Oct 18 separate/up-down maximum-entropy and joint common-vacuum log-determinant actions produced internal positive source roots Q≈0.496 and candidate CKM |V_cb|≈0.99995. These are **tests of a proposed alternative physical Yukawa dictionary**; they do NOT contradict the already frozen v35 Y24 wall-current result.
- Oct 18 13-point fractional Fourier/QR k=0..3 quartet is orthogonal but need not be the symmetry-defined 1⊕3 eigenspace; column-only phase rephasing cannot move eigenvalues. QR is an optional coordinate transform, not an independently closed generation mass mechanism.
- Simple 2/9→0.222222047 screened Koide formula matches a mass-inferred phase numerically but its coupling/normalization and stationarity were not obtained uniquely from the source action. Do not label it a prediction.
- A pair of non-commuting quark root-mass matrices can each have Q=2/3: commutator alone does not force either Q to rise. A complete joint source action must move spectra.

## SUPERSEDED / RETIRED AS PROJECT FRONTIER
- The logic 'recent surrogate Yukawa fails ⇒ Cathedral flavour failed' is invalid. Retire it as a global inference, while preserving the numerical result as a diagnostic for that surrogate.
- The logic 'frozen CKM matrix reproduced from its already constructed response frame ⇒ independent verification against nature' is also invalid. Preserve the exact internal residue theorem, but keep genuine predictive status conditional.
- Repeated new Koide, QR, entropy, and naive positive-Hessian eigenvalue re-tests must not displace the wall response and original selected-history transport.

## NEXT PHYSICS CALCULATION — KEEP THIS ORDER
1. Start at the **already frozen Y24/D48 L=13 wall response and original H64 selected-history action**; no generic new Yukawa ansatz.
2. Construct the interacting finite-cutoff, gauge-projected two-point fermion function S_f(p) and charged-current three-point function Γ_W^μ(p+q,p), with selected transfer and source-current coupling specified independently of measured mass/mixing.
3. Verify the weak charged-current Ward/Slavnov-Taylor identities with the very same transfer and source. Only then extract on-shell/finite-cutoff poles, residues and CKM/PMNS as physically normalized observables.
4. Freeze all coefficients and compare mass ratios, angles, and Jarlskog invariants with data at a common scale and scheme. Failed tests only change closure status for the exact defined physical model they test.

**Source priority note:** This is a continuity/precedence correction, not a claim that these listed physical gates have now been solved. Its evidence was recovered from chats and local Library files, not from a repository.
