import numpy as np
from math import pi,sqrt,log,exp,sin,cos,cosh
from scipy.optimize import minimize_scalar, brentq
phi=(1+sqrt(5))/2;d=3/20-(80/81)*pi/(13*phi);b=-log(d)
k1=sqrt(3/5);k2=1/sqrt(15);a=1/(4*(1+d*d));c=d*d*a
Z0=12*exp(-3*b)+4*exp(-7*b)
def KL(g):return (a-c)*2*b*(sin(k1*g)**2+3*sin(k2*g)**2)
def Zn(g):return sum(m*(2*exp(-3*b)*cosh(b*g*k)+2*exp(-5*b)*cosh(b*sqrt(4+g*g*k*k))) for k,m in [(k1,1),(k2,3)])
def action(g):return KL(g)-log(Zn(g)/Z0)
for g in [0,d,2*d,.01,.1,.2,.3,.5,.75,1,1.5,2,3,3.8]: print(g,action(g),KL(g),-log(Zn(g)/Z0))
for mx in [.5,1,2,3,3.8]:
 s=minimize_scalar(action,bounds=(0,mx),method='bounded',options={'xatol':1e-12});print('min<=',mx,s.x,s.fun)
