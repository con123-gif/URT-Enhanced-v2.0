#!/usr/bin/env python3
"""Source-exact gate for whether native geometry+Gibbs fixes g or Koide.
No empirical masses, no fitted parameters, no GitHub."""
import math, json
import numpy as np
from scipy.optimize import minimize_scalar
phi=(1+math.sqrt(5))/2
Delta=3/20-(80/81)*math.pi/(13*phi)
beta=-math.log(Delta)
k_s=math.sqrt(3/5);k_t=1/math.sqrt(15)

def levels(g):
    spec=[]
    for k, mult in ((k_s,1),(k_t,3)):
        es=[3-g*k,3+g*k,5-math.sqrt(4+(g*k)**2),5+math.sqrt(4+(g*k)**2)]
        for e in es: spec.extend([float(e)]*mult)
    return np.asarray(sorted(spec))

def gibbs(g):
    e=levels(g)
    w=np.exp(-beta*(e-e.min())); p=w/w.sum()
    S=-np.sum(p*np.log(p))
    E=np.dot(p,e)
    return dict(g=float(g),S=float(S),E=float(E),F=float(E-S/beta),pmax=float(max(p)),minimum=float(e.min()),Q_max=float(max(sum(e[list(inds)]**2)/(sum(e[list(inds)])**2) for inds in __import__('itertools').combinations(range(16),3))))

numerics=[gibbs(g) for g in [0,Delta/2,Delta,2*Delta,0.01,0.1,0.3,1.0,2.0]]
f=lambda g:gibbs(g)['S']; h=Delta/2
sec=(f(h)-2*f(0)+f(-h))/h**2
m=minimize_scalar(lambda g:-f(g),bounds=(0,0.5),method='bounded', options={'xatol':1.e-13})
# Koide on the *resonant splitting magnitudes*, i.e. the most charitable geometric mass map:
# g * (3,1,1)/sqrt15 -> Q=11/25. Pair (3,3,1) -> 19/49.
resonant_gap_Q=[sum(v*v for v in w)/(sum(w)**2) for w in [(1,1,1),(3,1,1),(3,3,1)]]
# Define one positive transfer H16(g)>0 interval roughly g<3/ks;
# explicitly exhibit same symmetries and positivity at three different couplings.
from itertools import combinations
result=dict(phi=phi,Delta=Delta,beta=beta,selection='Gibbs H16(g) with inherited beta',
 Gibbs_sweep=numerics,entropic_curvature_at_g0=sec,
 gibbs_entropy_max_0_to_point5=dict(g=float(m.x),S=float(-m.fun)),
 raw_splitting_Koide_candidates={'all_triplet':resonant_gap_Q[0], 'one_singlet_two_triplets':resonant_gap_Q[1], 'two_singlets_one_triplet':resonant_gap_Q[2], 'max':max(resonant_gap_Q)},
 tests={'g0_nonzeroDelta_max_entropy_loss':f(0)-f(Delta),'positive_H_at_multiple_g':{str(g):bool(levels(g).min()>0) for g in [0,Delta,.1,1]},'Koide_target':2/3},
 conclusion='Gibbs entropy has local maximum at g=0 (g=Delta is not stationary). Native symmetries, positivity and q spiral do not uniquely determine nonzero mixing amplitude. The resonant splitting magnitudes give Q<=11/25, not Koide.' )
with open('/mnt/data/urt_first_principles_attempt_20261023/selection_law_gate_results.json','w') as f2:json.dump(result,f2,indent=2)
for k in ('phi','Delta','beta','entropic_curvature_at_g0','gibbs_entropy_max_0_to_point5','raw_splitting_Koide_candidates'):print(k,result[k])
for row in numerics:print('g={g:.9g} S={S:.12f} E={E:.12f} F={F:.12f} Qmax={Q_max:.9f}'.format(**row))
