#!/usr/bin/env python3
"""Exact first-principles sufficiency audit: cross-dimensional H16 and frozen v59 charged-lepton mass ratios.
No observed masses are used. All results are computed from previously declared geometric and URT constants.
No GitHub access or writes.
"""
from itertools import combinations
from math import sqrt, pi, log
import json
import numpy as np
from scipy.linalg import block_diag
from scipy.optimize import minimize_scalar
from pathlib import Path
import mpmath as mp

O=Path(__file__).resolve().parent
mp.mp.dps=48
phi=(1+mp.sqrt(5))/2
Delta=mp.mpf(3)/20-mp.mpf(80)/81*mp.pi/(13*phi)
beta=-mp.log(Delta)
ks=mp.sqrt(mp.mpf(3)/5);kt=1/mp.sqrt(15)
# The even and odd combinations of two copies of 4_3 + 4_5 exactly diagonalize interlayer transfer.
def eigenvalues(g):
 e=[]
 for k,m in [(ks,1),(kt,3)]:
  e.extend([3-g*k]*m+[3+g*k]*m+[5-mp.sqrt(4+(g*k)**2)]*m+[5+mp.sqrt(4+(g*k)**2)]*m)
 return sorted(e)

# Source-original, not fitted thermal parameter beta=-lnDelta and Gibbs state.
def Z(b,g):
 return sum(m*(2*mp.exp(-3*b)*mp.cosh(b*g*k)+2*mp.exp(-5*b)*mp.cosh(b*mp.sqrt(4+(g*k)**2))) for k,m in [(ks,1),(kt,3)])

def S(g):
 z=lambda b:mp.log(Z(b,g))
 return z(beta)-beta*mp.diff(z,beta)

def F(g):return -mp.log(Z(beta,g))/beta

# Mass formula (already declared in the archived September 5 v59 branch):
# tau=(D+1)Delta, mu=tau*(D*h*Delta), e=tau*(2D*h*Delta^2)*(d_star/d_cl)^2
D=mp.mpf(3);h=mp.mpf(8)
dstar=mp.mpf(80)/81*mp.pi/(13*phi); dclass=mp.mpf(3)/20
ratio_e=2*D*h*Delta**2*(dstar/dclass)**2
ratio_mu=D*h*Delta
lepton_roots=[mp.sqrt(ratio_e),mp.sqrt(ratio_mu),mp.mpf(1)]
Q_wall=sum(v*v for v in lepton_roots)/(sum(lepton_roots)**2)

# Numerical native matrix built from exact singular values of tetrahedral A4 gate.
g=float(Delta)
k_real=np.diag([float(ks)]+[float(kt)]*3)
Lh=np.diag([3.]*4+[5.]*4)
W=np.block([[np.zeros((4,4)),k_real],[k_real,np.zeros((4,4))]])
C=np.diag([0.]*4+[-2.]*4)
J=np.diag([-1.]*4+[1.]*4)
H16=lambda t:np.block([[Lh+t*W,C],[C,Lh+t*W]])
J16=block_diag(J,J)
for t in [0,g,1.]:
 mat=H16(t)
 assert np.max(np.abs(np.linalg.eigvalsh(mat)-np.array([float(x) for x in eigenvalues(t)])))<4e-14
 assert np.linalg.norm(J16@mat@J16-H16(-t))<1e-13
assert np.allclose(W@J,-J@W)

# Positive transfer permits infinitely many g: two distinct strictly positive H16 commute
# with the same A4 representation; q-unitary left factors cannot determine the spectrum.
mpQ=lambda es:sum(x*x for x in es)/(sum(es)**2)

def extremal_raw(g):
 es=np.array([float(v) for v in eigenvalues(g)])
 best=max((sum(es[np.array(c)]**2)/(sum(es[np.array(c)]))**2,c) for c in combinations(range(16),3))
 return {'Qmax':best[0],'indices':list(best[1]),'root_candidates':[float(es[j]) for j in best[1]]}

# Entropy and free energy curvatures are exact derivatives, not finite-difference estimates.
S0=S(mp.mpf(0));Sd=S(Delta)
Spp=mp.diff(S,mp.mpf(0),2);Fpp=mp.diff(F,mp.mpf(0),2)
# Determinant identity (true for all real g inside the positive interval)
# det H16(g) = ((9-(3/5)g²)(21-(3/5)g²)) * ((9-(1/15)g²)(21-(1/15)g²))³
q_split={'one_singlet_two_triplets':11/25, 'two_singlets_one_triplet':19/49, 'all_triplets':1/3}
result={
 'date':'2026-10-23', 'source_archives':['CATHEDRAL_CROSS_DIMENSIONAL_RESONANCE_2026_10_21.zip','Newton_Cathedral_Full_v59.py'],
 'scope':'First-principles sufficiency audit, not proof of an experimentally validated unified theory',
 'geometry':{'phi':float(phi),'Delta':float(Delta),'H16_interlayer_C_4_5':-2,'W_singular_singlet':float(ks),'W_singular_triplet':float(kt),'W_split_ratio':3},
 'exact_determinant_formula':'(9-3g²/5)(21-3g²/5)[(9-g²/15)(21-g²/15)]³',
 'parity':'J16 H16(g) J16 = H16(-g), all spectral invariants even in g',
 'Gibbs':{'beta':float(beta),'S_g0':float(S0),'S_gDelta':float(Sd),'difference':float(Sd-S0),'S_second_derivative_g0':float(Spp),'free_energy_second_derivative_g0':float(Fpp), 'gDelta_stationary':False},
 'native_operator':{'minimum_eigenvalue_g0':float(min(eigenvalues(0))), 'minimum_eigenvalue_gDelta':float(min(eigenvalues(Delta))), 'minimum_eigenvalue_g1':float(min(eigenvalues(1))),
  'max_raw_Q_gDelta':extremal_raw(Delta), 'max_raw_Q_g1':extremal_raw(1), 'max_Q_three_resonance_gaps':11/25},
 'legacy_v59_closed_response_path':{'tau_mass_ratio':1,'mu_over_tau':float(ratio_mu),'electron_over_tau':float(ratio_e),'charged_lepton_Koide_Q':float(Q_wall),'difference_from_exact_two_thirds':float(Q_wall-mp.mpf(2)/3), 'interpretation':'the declared serial attenuation formula, not a first-principles root-mass spectrum from geometric H16'},
 'uniqueness_counterexample':'g=0 and g=Delta and g=1 all obey symmetry, grading covariance, positivity and the same geometric phase conventions; g is not determined without independent selection action',
 'Koide_algebra':'C3-invariant root-mass X=aI+zS+conj(z)S† has Q=1/3+2|z|²/(3a²), requiring |z|/a=1/sqrt(2)',
 'physical_outcome':'Inherited Gibbs entropy locally maximizes at g=0. Geometry fixes the W ratio but cannot select nonzero g or an A4-to-C3 mass splitting. Raw resonance gaps max Q=11/25; earlier frozen serial-response lepton ratios give Q≈0.6662339186, not exact 2/3. Need microscopic dynamical chiral source and gauge-covariant physical pole dictionary.'
}
(O/'complete_source_selection_results.json').write_text(json.dumps(result,indent=2)+'\n')
for section in ['Gibbs','native_operator','legacy_v59_closed_response_path']:
 print(section,json.dumps(result[section],indent=2))
print('Generated', O/'complete_source_selection_results.json')
