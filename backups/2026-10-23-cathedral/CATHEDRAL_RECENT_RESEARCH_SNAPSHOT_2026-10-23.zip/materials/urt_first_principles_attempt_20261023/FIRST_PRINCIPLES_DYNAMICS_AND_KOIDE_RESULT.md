# Newton's Cathedral / URT — first-principles dynamical selection test

**23 October 2026 · executed with frozen geometric inputs; no empirical masses or fitted coefficients; GitHub untouched.**

## What was tested

The 600-cell, 24-cell and icosahedral face incidence produce two hidden quartets with eigenvalues 3 and 5. A tetrahedral four-face difference gate W has no diagonal 4_3 or 4_5 components, with four off-diagonal singular values sqrt(3/5), 1/sqrt(15), 1/sqrt(15), 1/sqrt(15). The 6D cube interlayer coupling is zero on 4_3 and has magnitude 2 on 4_5. Identifying the two 4_5 frames coherently gives the **conditional** exact H16(g) from the October 21 archive, retaining g as a free physical coupling; g=Delta was formerly inserted as a composition rule, not derived from history selection.

## Exact microscopic finite operator and determinant

    H16(g) = [[Lhid+g W, C], [C, Lhid+g W]]
    Lhid = diag(3 I4, 5 I4), C=diag(0 I4, -2 I4).

For k_s²=3/5 with multiplicity 1 and k_t²=1/15 with multiplicity 3, the exact eigenvalues are

    3 ± g k,  5 ± sqrt(4+g² k²).

Thus the full zero-energy determinant is exactly

    det H16(g)=(9-3g²/5)(21-3g²/5)*[(9-g²/15)(21-g²/15)]³.

The resonant 3-sector energy-dependent Schur inverse is

    K_k(E) = (E-3) - g²k²/(E-3).

The A4 triplet is multiplied by I3: K_t(E)=[(E-3)-g²/(15(E-3))] I3. It therefore **cannot** yield three distinct charged-lepton poles without an independent physically selected A4→C3-breaking source. Its two resonant poles have geometric residues 1/2 in each channel. Those are not yet charged-lepton propagator residues.

The geometric parity J16 obeys `J16 H16(g) J16 = H16(-g)`. Accordingly, determinants, eigenvalues, Gibbs entropies and all even spectral observables are insensitive to which tetrahedral orientation is chosen. A physical orientation selector needs an operator that is odd under this parity, sourced by the original ordered URT history, not inserted as a fitted mass phase.

## First-principles Gibbs selection attempt

Use precisely the Cathedral's inherited thermal inverse scale beta=eta_Delta=-ln Delta, Delta=3/20-(80/81)pi/(13phi). The partition function of the full 16-state operator is *exactly*

    Z(beta,g)= sum_{(k,m)=(sqrt(3/5),1),(1/sqrt(15),3)}
       m [ 2 exp(-3beta) cosh(beta g k)
         + 2 exp(-5beta) cosh(beta sqrt(4+g²k²)) ].

The free energy is F=-(1/beta) ln Z; the density matrix is exp(-beta H)/Z, and entropy S/k_B=ln Z-beta d(lnZ)/d beta, holding g fixed in that temperature derivative.

`Z(beta,0)=12 exp(-3beta)+4 exp(-7beta)`.

Exact derivatives yield a **parameter-free cross-dimensional susceptibility**

    chi_cross = -d²F/dg²|0
              = (2/5)*[beta+(1-exp(-4beta))/4]/[3+exp(-4beta)]
              = 0.8327730648869041.

Also `S''(0)/k_B = -beta² (d chi_cross/d beta) = -4.793279134696629`.

Numerically:

| g | S/k_B | F |
|---|---:|---:|
| 0 | 2.484906650107712 | 2.585558643687504 |
| Delta/2 | 2.484902937671 | 2.585557998698 |
| Delta | 2.484891800332738 | 2.585556063727 |
| 2Delta | 2.484847250553 | 2.585548323826 |

**Verdict:** If one tries to select the interaction by maximizing this inherited Gibbs entropy *over g*, g=0 is a strict local maximum. If one instead minimizes the matter free energy alone, g=0 is locally unstable and F falls as |g| grows; neither principle selects the small nonzero g=Delta. Such maximization over Hamiltonians is itself a separate physical proposal—the standard maximum-entropy principle fixes rho **for a given Hamiltonian**, not the Hamiltonian's microscopic coupling.

A genuinely dynamical stiffness K for the order parameter would produce

    Gamma_eff(g)=K g²/2 - (1/beta)ln Z(beta,g)+higher or source terms.

Its **calculable local instability threshold** is K_c=chi_cross=0.8327730648869041. For K>K_c g=0 is locally stable; for K<K_c it is unstable. K and an oriented odd history source are not fixed by the present geometry, so neither g=Delta nor the chosen sign has been derived. Claiming spontaneous chirality or a physical mass on this basis would be premature.

## Independent physical mass diagnostics

For any three resonant **gap magnitudes**, the singlet/triplet ratio is fixed to 3:1. The largest Koide-style quotient from three such magnitudes is

    Q(3,1,1)=(9+1+1)/(3+1+1)^2=11/25=0.44,

not 2/3. Directly using three positive native H16(g=Delta) energies gives maximal Q=0.39651528784294415; using a geometrically unscaled g=1 gives maximal Q=0.43297634773992777. No physical root-mass identification of these geometric energies has been justified.

I also recovered the September v59 charged-lepton *serial-response mass tree* as written, without changing it:

    m_mu/m_tau=24 Delta=0.05974055617008943,
    m_e/m_tau=48 Delta² (d_star/d_cl)²=0.00028762223405747465.

These particular **declared response formulas**, independently evaluated, give

    Q_e=(m_e+m_mu+m_tau)/(sqrt(m_e)+sqrt(m_mu)+sqrt(m_tau))²
       =0.666233918575197,

which is 0.00043274809146967 below the exact 2/3 value. This is a check of one frozen branch, not a global falsification and not a new mass rule. The September L=13 wall proves it can reproduce these already-declared factors and weak mixing matrices. It has not been shown that the present H16 transfer uniquely produces their factor paths.

## Why one first-principles microscopic selector is still indispensable

The two 4D hidden quartets each restrict under A4 as 1+3. Hence A4-equivariant mixing allows **two independent channels** (one singlet and one triplet); the geometric difference face-gate fixes their ratio to 3:1, but any overall g remains symmetry-compatible. For example g=0, g=Delta and g=1 all leave H16 positive and have the same geometric symmetries. Positivity and the finite geometry therefore do not imply a unique nonzero value of g.

The canonical π/e, 2π/phi² URT spiral is represented by a symplectic transport and its unitary metaplectic lift U_URT. If positive transfer is formed as C=U_URT B, then `C†C=B†B`: purely unitary phase rotation cannot alter singular values or force Koide. An actual *nonunitary selected history* B that changes singular values and breaks A4→C3 through a specified oriented microscopic kernel is required, and the charged-lepton physical on-shell propagator must be extracted from it. Neither that B nor the intergeometry registration is selected by the currently supplied axioms.

**Actual advance:** an exact all-dimension thermal susceptibility and critical stiffness, exact retained Green kernel and source-level mass diagnostics, with explicit proof of why the previously used entropy rule cannot select g=Delta. This is a concrete test of a proposed first-principles route—not a completed microscopic theory of nature.

## Reproduction and provenance

Scripts `complete_source_selection_audit.py` and `selection_law_gate.py` create machine-readable results; the exact cross-dimensional rational/projector proof is in `combined_coset_audit.py` (preserved Oct 21 archive), and the earlier original `Newton_Cathedral_Full_v59.py` contains the unchanged declared `response_mass_certificate()` and `microscopic_response_wall_certificate()` functions. **No GitHub access or modification during this run.**

## Additional exact BKM information-geometry test (new)

The previous trial used only the hypercube Gibbs state. There is also the Cathedral's original eight-state selected density `rho_star=(I4 ⊕ Delta² I4)/[4(1+Delta²)]`. A direct, parameter-free way to test tetrahedral information stiffness is to rotate this state with the **same normalized geometric** off-diagonal W:

    rho(g)=exp(i g W) rho_star exp(-i g W).

Its von Neumann entropy stays constant under that unitary rotation, but its **relative entropy** with respect to the selected reference rho_star is nonzero. Exact two-state calculations in each singular-value channel give

    D(rho(g)||rho_star) = [beta(1-Delta²)/(2(1+Delta²))]
      * [sin²(g sqrt(3/5)) + 3 sin²(g/sqrt15)].

The exact BKM quadratic information stiffness is

    K_BKM=D''(0)=(4/5)*beta*(1-Delta²)/(1+Delta²)
         =4.796578949184679.

This formula was independently verified by direct 8x8 matrix exponentiation and evaluation of the relative-entropy trace to better than 5e-16 absolute.

For a **candidate** coefficient-one dimensionless selector

    Gamma_trial(g) = D(rho(g)||rho_star) - ln[Z(beta,g)/Z(beta,0)],

the exact origin curvature is

    Gamma_trial''(0)=K_BKM-beta chi_cross=-0.196560116676622.

Thus this particular synthesis of canonical information geometry and thermal history dynamics can produce an instability of the unmixed solution (unlike Gibbs-entropy maximization alone). However, it **does not select** the tiny nonzero g=Delta: on the tested interval 0 to 3, Gamma_trial decreases as |g| grows, rather than developing a minimum at Delta. It needs an independently derived bounded-history constraint or nonlinear interaction.

**Precise conditional route:** If URT's already frozen scalar rail dynamics is additionally demonstrated to couple as `g=d_cl-d` to this exact face-selector W, its deterministic limit is `g=Delta`. On that small interval the trial action decreases to its endpoint, so the nonzero magnitude is dynamically preferred. But establishing `g=d_cl-d` on the face-carrier and the coefficient-one combined action from the original history kernel is the outstanding microscopic derivation; **neither identification may be advertised as proven merely because it yields a desired result**. Nor does g=Delta give Koide: the triplet still has exactly three equal pole positions.

Reproduce: `python bkm_history_selector_test.py`; result file `bkm_history_selector_results.json`.
