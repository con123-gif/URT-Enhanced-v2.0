#!/usr/bin/env python3
"""Exact BKM relative-entropy stiffness vs hypercube Gibbs susceptibility.
Tests a candidate *combined* selector; does not assert its addition/normalization
is an established microscopic URT action. No observed inputs or fitting.
"""
import math,json
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize_scalar
O=Path(__file__).resolve().parent
phi=(1+math.sqrt(5))/2
Delta=3/20-(80/81)*math.pi/(13*phi);beta=-math.log(Delta)
k=np.array([math.sqrt(3/5)]+[1/math.sqrt(15)]*3)
K=np.diag(k)
W=np.block([[np.zeros((4,4)),K],[K,np.zeros((4,4))]])
a=1/(4*(1+Delta**2));bb=a*Delta**2
rho0=np.diag([a]*4+[bb]*4)
logrho0=np.diag([math.log(a)]*4+[math.log(bb)]*4)


def relative(g):
 U=expm(1j*g*W)
 r=U@rho0@U.conj().T
 L=U@logrho0@U.conj().T
 return float(np.trace(r@(L-logrho0)).real)

def relative_exact(g):
 return (a-bb)*2*beta*(math.sin(g*k[0])**2+3*math.sin(g*k[1])**2)

Z0=12*math.exp(-3*beta)+4*math.exp(-7*beta)
def Z(g):
 return sum(mult*(2*math.exp(-3*beta)*math.cosh(beta*g*kk)+2*math.exp(-5*beta)*math.cosh(beta*math.sqrt(4+g*g*kk*kk))) for kk,mult in ((k[0],1),(k[1],3)))
def action(g):return relative_exact(g)-math.log(Z(g)/Z0)
K_BKM=(4/5)*beta*(1-Delta**2)/(1+Delta**2)
chi=(2/5)*(beta+(1-Delta**4)/4)/(3+Delta**4)
curvature=K_BKM-beta*chi
checks=[(g,relative(g),relative_exact(g)) for g in [0,Delta,0.1,1.0]]
assert max(abs(p-q) for _,p,q in checks)<1e-12
scan=[{'g':float(g),'D_BKM':relative_exact(g),'minus_logZratio':-math.log(Z(g)/Z0),'candidate_action':action(g)} for g in [0,Delta/2,Delta,.01,.1,.5,1.,2.,3.]]
res=dict(Delta=Delta,beta=beta,exact_BKM_curvature=K_BKM,exact_cube_Gibbs_susceptibility=chi,candidate_combined_curvature=curvature,formula='D_BKM(g)=[beta(1-Delta²)/(2(1+Delta²))]*(sin²(g sqrt(3/5))+3 sin²(g/sqrt15))',matrix_verifications=checks,action_sweep=scan,interpretation='The proposed coefficient-one D_BKM -lnZ action has negative curvature at zero and continues decreasing on tested domain. With no independent bounding/elastic term it does not select a small g=Delta; coupling this gate to the URT rail interval |g|<=Delta would select its endpoints, but the identification and rail constraint on g are additional physical premises, not derived from the 600-cell itself.')
(O/'bkm_history_selector_results.json').write_text(json.dumps(res,indent=2)+'\n')
print('K_BKM',K_BKM, 'chi',chi,'curvature',curvature)
for row in scan:print(row)
print('matrix max verification error',max(abs(p-q) for _,p,q in checks))
