# Newton's Cathedral — physical quark Yukawa, charged-current and pole-matching audit
18 October 2026

## Why this test is physics rather than another entropy invariant
Use the untouched source array `golden_species_operators.npz` (SHA256 `9bfd183c01b43e3a589917f334ec5758cefb912cf30f55147b58ccb496b0399b`) and the 13-component **shared** history stationary point x of the Oct 8 archived common-vacuum determinant completion. No physical masses or CKM mixing parameters enter the construction or minimization.

The exact source choice is `A_f(x) = complex_amplitude_sources[f] + sum_i x_i C_i`, with `C_i=reshape((affine_L_plus [F5 Qplus Qminus]).T)[i]`; f=u,d. Assume for this stringent physical matching test that `A_f(x)` are the two Higgs Yukawa matrices, with a **single canonical left-handed quark doublet generation space** and Lagrangian `-\bar u_R A_u \tilde H^\dagger Q_L - \bar d_R A_d H^\dagger Q_L + h.c.` (up to conventional Higgs dual/transposes). The physical tree-level poles would be `p²=v² eig(A_f† A_f)/2`. The resulting CKM matrix is `U_{uL}†U_{dL}`, where `U_f` diagonalize the **same-left-space** positive operators `A_f†A_f`.

### Direct physically interpretable numerical results (under this mapping)

Common x Euclidean norm: 0.374531261456179; action gradient ~1.85e-15. Singular values:
- up: (0.0121211952434,1.0139245247761,1.1499104497975)
- down: (0.0121027720103,0.8501489291687,0.9861310759915)

Root-mass Koide diagnostics: Q_u=0.496428830938, Q_d=0.496222685140.
Physical mass ratios **if these amplitudes are Yukawa**:
- u/t = 0.0105409906011; c/t = 0.881742160839
- d/b = 0.0122729851082; s/b = 0.862105403497.
- t/b (Yukawa heavy singular value ratio) = 1.166.

Measured-mass benchmark from user-supplied cross-scale values (use only for order-of-magnitude comparison; these are not one consistent MSbar running scale):
- u/t=1.250796224e-5; c/t=0.00735421854
- d/b=0.00111722488; s/b=0.02234449761.

Left-handed weak-current CKM matrix absolute values:
```
[0.999915230  0.009301538  0.009111247]
[0.009077648  0.004841904  0.999947075]
[0.009334332  0.999945017  0.004778378]
```
Unitarity residual `||V†V-I||F=6.59e-16`; invariant `J = +2.69766739e-7` (the overall sign depends on ordering convention). Compare the user-frozen target magnitudes `|Vus|=0.22430886`, `|Vcb|=0.04217751`, `|Vub|=0.00373378`, `J~3.14136e-5`.

This is **a failed physical mass-and-mixing prediction for the specific common-13-history determinant completion under the natural tree-level Yukawa matching**, not a global obstruction of other URT/H64 constructions, and not a valid physical loop computation. No parameters tuned.

### Alternative source frames / test of origin

Original primitive `u_source_only_A/d_source_only_A` in the same left 3-chart yield up ratio `(0.212610,0.787399,1)`, down ratio `(0.275606,0.724396,1)` and CKM magnitudes `(Vus,Vcb,Vub)=(0.259055,0.978722,0.195102)`. The `lower_direct` and `lower_polynomial` source projections are reported in `h64_quark_source_variants_physics.json`, but their source-dependent lower frames do **not** establish a single physically normalized `Q_L` basis; their overlap is **not** automatically a CKM prediction. Thus swapping finite compressions would not be a justified repair.

### 64D pole cross-check

The actual archived 64D **positive Hessian**, diagonalized without fitting, has generation-overlap-selected eigenvalues:
- up `(0.01519184869690,0.50637101713120,0.83822862979924)` with overlap residues `(0.998102,0.962039,0.980917)`;
- down `(0.00828285132137,0.19895677328688,0.37158069436587)` with overlap residues `(0.999592,0.987134,0.998102)`.

These finite Hessian eigenvalues are **not** automatically fermion mass poles: no source-derived Minkowski inverse Dirac propagator `S_f^{-1}(p)`, momentum-dependent self-energy, canonically normalized left-handed gauge vertex `\Gamma_W^\mu`, nor gauge-invariant Higgs vacuum matching has been identified in these arrays. A provisional 64D weak-current projector `E_u E_d†` produces a 3x3 effective overlap with unitarity defect `||V†V-I||F=0.06230`, *not* a physical CKM value without the actual W generator and wavefunction residue matching.

### Physically productive next mathematical construction

The required minimal action is `\bar Q_L i\not D Q_L + \bar u_R i\not D u_R + \bar d_R i\not D d_R -\bar Q_L(Y_u[x]\tilde H u_R+Y_d[x]H d_R)+h.c. +S_URT[x]+S_H`, where `Y_f[x]` and the coframe/positive-transfer density must be derived from the original histories rather than assumed. With that action one can derive `S_f^{-1}(p)`, impose a charged-current Ward–Takahashi/Slavnov–Taylor identity, and compute genuine pole masses and `V_CKM` including residue matrices. The current 13D scalar common-vacuum determinant is insufficient for that identification. The shared-history mixed source susceptibility `-0.867190411` is a Hessian response, **not by itself** a weak gauge interaction or a quark mass.

See `h64_physical_quark_weakcurrent_test.py`, `h64_physical_quark_weakcurrent_results.json`, `h64_quark_source_variants_physics.py`, and `h64_quark_source_variants_physics.json` for independent reproducible numerical checks. Neither the source NPZ nor original archived work was changed.
