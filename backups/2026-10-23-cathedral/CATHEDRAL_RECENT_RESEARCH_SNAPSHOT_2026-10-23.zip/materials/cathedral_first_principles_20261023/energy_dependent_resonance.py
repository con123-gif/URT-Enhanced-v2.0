#!/usr/bin/env python3
"""Exact Schur/Dyson residues of conditional cross-dimensional H16.
No fitting. Distinguishes finite geometric poles from physical Dirac poles.
"""
import math, json
import numpy as np
from pathlib import Path
phi=(1+math.sqrt(5))/2
Delta=0.15-(80/81)*math.pi/(13*phi)
results={}
for name,k2 in [('singlet',3/5),('triplet',1/15)]:
    t=Delta*math.sqrt(k2)
    resonant=np.array([[3,t],[t,3]],float)
    far=np.array([[3,t],[t,7]],float)
    E,U=np.linalg.eigh(resonant)
    Ef,Uf=np.linalg.eigh(far)
    residues=np.abs(U[0,:])**2
    rf=np.abs(Uf[0,:])**2
    # z-H inverse projected onto protected level
    for z in (complex(4,0.2),complex(5,-0.3)):
        invfull=np.linalg.inv(z*np.eye(2)-resonant)[0,0]
        invschur=1/(z-3-t*t/(z-3))
        assert abs(invfull-invschur)<1e-12
    assert max(abs(E-np.array([3-t,3+t])))<1e-12
    assert max(abs(residues-0.5))<1e-12
    assert max(abs(Ef-np.array([5-math.sqrt(4+t*t),5+math.sqrt(4+t*t)])))<1e-12
    results[name]={
        'squared_face_coupling':k2,'t':t,
        'resonant_poles':E.tolist(), 'resonant_retained_residues':residues.tolist(),
        'nonresonant_poles':Ef.tolist(), 'nonresonant_retained_residues':rf.tolist(),
        'nonresonant_small_shift':Ef[0]-3
    }
out=Path(__file__).with_name('energy_dependent_resonance_results.json')
out.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
