# Newton’s Cathedral — first-principles gate, 23 October 2026

**Scope:** reconcile the cross-dimensional 600-cell, 24-cell, icosahedron, dodecahedron, six-cube, hidden 4_3/4_5, H16 resonance and earlier L=13 Y24/D48 mass-current theory. No GitHub changes. No observed particle masses or CKM values in the calculations in this record.

## What is already a mathematical theorem relative to specified geometry

Re-ran `combined_coset_audit.py` from the preserved 2026-10-21 source. It passed all exact rational/projector tests and the full H16 eigenvalue check (max discrepancy 4.0e-15). The 600-cell's binary-tetrahedral selection gives five cosets of 24-cell vertices and a local icosahedron with vertex-face incidence B: rank(B)=12, dim ker(B)=8; the dodecahedral Laplacian on ker(B) gives 3 x4 and 5 x4. Choosing two A4-symmetric four-face orbits yields exact parity-odd W: P3WP3=P5WP5=0 and singular values of P3WP5 equal sqrt(3/5) once and 1/sqrt(15) three times. The 6D cube provides a separate interlayer coupling of magnitude 2 in 4_5 and zero in 4_3. Their energy matching 5-2=3 is exact.

## What the combination still assumes

The 16-state model H16(g)=[[L_hid+g W,C],[C†,L_hid+g W]] with C=(0_4)⊕(-2I_4) requires *coherent identification* of the two four-dimensional 4_5 frames. The native geometric symmetry does not by itself give a unique physical URT history map between 600-cell face modes and six-cube face modes. In addition, g can be any real scalar while the finite model retains the same symmetry. The choice g=Delta, Delta=3/20-(80/81)pi/(13 phi), is a specified URT **composition rule**, not a consequence of the Platonic graph data. Neither the stable coupling sign nor the spiral phase q=(pi/e)exp(i2pi/phi²) by itself fixes a particle mass basis.

## Exact combined poles and geometric residues

For either k²=3/5 (singlet) or k²=1/15 (triplet), layer even/odd reduction gives two 2x2 problems: [[3,gk],[gk,3]] and [[3,gk],[gk,7]]. Their four eigenvalues are 3±gk and 5±sqrt(4+g²k²). Eliminating the transmitting resonant partner yields K_k(E)=(E-3)-g²k²/(E-3); at both exact resonant poles its protected-sector residue [K'_k(E)]^-1=1/2 (confirmed by direct spectral projections and full 2x2 inversion). This is an intrinsic finite Green-function result: the exact degeneracy causes O(1) hybridization for arbitrarily small nonzero g, **not** a demonstrated physical fermion wave-function renormalization.

## Model-specific Koide gate

At g=Delta, the exact positive H16 spectrum has 12 levels near 3 and four levels near 7. Exhaustive enumeration of C(16,3)=560 triples yields maximum Q=sum(lambda_i²)/(sum lambda_i)² = **0.396515287842944**, which is below the required 2/3. Even if any three hypothetical candidate root masses were arbitrarily drawn from the entire continuous spectral interval [2.99807188184,7.00000092941], Q cannot exceed **0.396548084697594**. This rigorously rules out *directly taking three bare positive H16 eigenvalues as root masses*. It is not a no-go theorem for URT or the wall-derived physical mass operator.

## Exact necessary/sufficient C3 mass relation

Under a genuine physical A4->C3 reduction, a C3-invariant Hermitian three-generation root-mass operator has the form X=a I3+z S+z* S†, a>0, S³=I, z=b+ic. Its eigenvalues are a+2b, a-b+sqrt(3)c, a-b-sqrt(3)c (up to C3 orientation). Thus

    Q(X)=1/3 + 2*(b²+c²)/(3*a²),
    Q=2/3  iff  b²+c²=a²/2.

The threefold A4 sector forces b=c=0 and Q=1/3 if its triplet is interpreted directly as three root masses. Phase transport alone by X->U X U† cannot remove this degeneracy. The actual URT-selected *operator-valued* history coupling must generate z, and the physical entropy/selection equation must independently enforce |z|²=a²/2. Choosing a binary entropy of abstract trace/traceless norm weights **would** mathematically enforce the equality, but this is not first-principles physics unless that entropy follows from the original selected state and action.

## Restore the earlier wall construction without misrepresenting provenance

The recovered September v59 implementation defines `response_yukawa_matrices()` as `Y24 = mixing_holonomy @ diag(mass_diagonal)`, with `mass_diagonal` from the declared `response_mass_certificate()` recursive formulas and CKM/PMNS from `response_flavour_certificate()`. It then proves the L=13 wall Schur construction reproduces the declared Y24 and the current residues to internal numerical precision. That is a valid internal construction. It is **not** an independent calculation where the new 600-cell/hypercube geometry, by itself, produces the previously frozen mass and mixing formulas. To assert complete first-principles emergence, the primitive response rules in these functions must follow uniquely from the selected microscopic action, not be copied in from the endpoint target.

## The minimum complete physical derivation

A physical model must specify from the native geometry and URT history one common, positive/unitary/gauge-consistent action; its history measure and chirality/orientation selector; a *unique* interlayer coupling amplitude/frame; the actual gauge-covariant fermion kinetic and Yukawa operator; and the physical current vertex. Then compute the energy/momentum-dependent Feshbach/Dyson kernel `K_f(p)=S_f^{-1}(p)` and its on-shell zeros `det K_f(p)=0`, pole residues, charged-current CKM/PMNS matrix elements and RG evolution, with no measured masses in the operator construction. Exact gauge Lie algebra and the local spin connection are necessary structure, not sufficient field dynamics. Absolute dimensionful scales also require a derived dimensional-transmutation mechanism or physical boundary condition.

**Conclusion:** Geometry and the conditional H16 resonance are exact; its half-residues are new rigorous dynamical information. The all-dimensions-to-physical-masses uniqueness theorem and actual C3/Koide pole-selection equation have not yet been derived. Do not replace or discard the earlier finite wall closures; do not call this model-specific spectral limitation a global no-go.

**Reproduction:** `python combined_coset_audit.py`, `python first_principles_gate.py`, `python energy_dependent_resonance.py`.
