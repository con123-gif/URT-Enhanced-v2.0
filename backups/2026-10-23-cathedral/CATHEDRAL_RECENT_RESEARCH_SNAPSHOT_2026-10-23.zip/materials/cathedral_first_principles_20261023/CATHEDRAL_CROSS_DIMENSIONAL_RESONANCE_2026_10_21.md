# Newton's Cathedral — cross-dimensional hidden-sector coupling and exact resonance

**Date:** 21 October 2026. **Status:** newly calculated exact finite-geometric operator theorem; conditional two-layer URT coupling, not physical Koide or CKM closure. **GitHub unchanged.** The 600-cell vertices, local icosahedron, face incidence and six-dimensional hypercube derive from earlier archived Oct 20–21 audited source programs. All algebra below was rerun in this work. No masses, CKM values, CP angles or dimensionless couplings were fitted.

## 1. All five Platonic solids enter two exceptional four-dimensional geometries

- 600-cell {3,3,5}: its cells are **tetrahedra** and its vertex figure is the **icosahedron**. The 20 local triangular icosahedral faces give the dual **dodecahedron** graph.
- 24-cell {3,4,3}: its cells are **octahedra** and its vertex figure is the **cube**.
- Thus the tetrahedron, icosahedron, dodecahedron, octahedron, and cube all occur via geometrically specified cells, vertex figures, or duals. This is not the same as claiming their unrelated graph Laplacians have a universal physical coupling.
- The 6D hypercube supplies a genuinely different 64-state **transfer** action; the 600-cell also contains a 64-state selected subset, but its induced graph is not the 6D cube.
- The 5D ambient/four-leaf sector labels the pre-existing URT flow, not an additional 5-fold tensor factor. The E8 McKay graph of the 600-cell spinor representations is distinct from a physical eight-dimensional E8 space; the 24D Leech program has no derived coupling to the present finite operator.

## 2. Five tetrahedral 24-cells and A5 → A4

The vertices of the 600-cell are the binary icosahedral quaternions 2I (120 elements). Its 24 Hurwitz-unit vertices form a closed binary tetrahedral subgroup 2T (24 elements). Explicit quaternion multiplication yields five disjoint cosets of exactly 24 vertices; the subgroup's conjugation actions on the local 12-neighbour icosahedron form the 12 rotations of A4. The 12 local vertices lie 3 per four nontrivial cosets. The 20 triangular faces split into A4 orbits **12+4+4**, directly enumerated.

As A5 modules, the two triplets 3,3' restrict to the same A4 irreducible triplet; the exact character inner product gives **dim Hom_A4(3,3')=1**. This makes the earlier typed generation bridge symmetry-allowed after tetrahedral selection, but does not fix its physical Yukawa strength or phase.

## 3. An exact chiral coupling between the Cathedral's two hidden quartets

Let B be the **integer** 12×20 incidence matrix from icosahedron vertices to its 20 triangles, and L20 the dodecahedral graph Laplacian. Define

    Pker=I20-Bᵀ(BBᵀ)⁻¹ B;
    P3=((5 I20−L20)/2)Pker;
    P5=((L20−3 I20)/2)Pker.

These are exact rational projectors, with ranks 8,4,4, and their spectra on the kernel are respectively 3×4, 5×4. For the two tetrahedral four-face orbits A and B, let DA and DB be their diagonal 0/1 projectors. The **signed chiral face-selector** is

    W=Pker(DA−DB)Pker.

Exact symbolic rational calculation proves

    P3 W P3 = P5 W P5 = 0,
    J W + W J = 0, where J=P5−P3 on the eight-state kernel.

Thus in the 4_3 ⊕ 4_5 hidden basis, W has pure off-diagonal form [[0,K],[K†,0]]. For either individual four-face orbit the singular squares of P3 DA P5 are 3/20 once, 1/60 three times. The exact minimal-polynomial test is

    M(M−3I/20)(M−I/60)=0,
    M=P3 DA P5 DA P3,
    rank M=4, tr M=1/5, tr(M²)=7/300.

Hence the **difference-selector** W has four singular values

    **√(3/5), 1/√15, 1/√15, 1/√15**

and real eigenvalues ±√(3/5) once and ±1/√15 three times. These values hold in the real face-incidence Hilbert space and are independent of any phenomenological particle masses. The two 4-face orbits have opposite K and identical single-orbit spectra.

For the **single-orbit symmetric gate** L20+DA, restricted to ker B, the exact eigenvalues are

    singlets: (22±2√6)/5,
    triplets: (62±2√61)/15 (each 3-fold).

These were evaluated numerically and also checked using rational spectral projectors.

## 4. Exact resonance when the hypercube is included

Previously established on the actual six-cube adjacency: there is no interlayer 4_3 coupling, and 4_5 interlayer transfer has four singular values **2**. Combined with local dodecahedral Laplacian energies 3 and 5, the bonding 4_5 energy is **5−2=3**, coinciding exactly with the protected 4_3 energy. At zero tetrahedral mixing the 16-state two-layer hidden operator therefore has spectrum **3×12, 7×4**.

To test the simplest coherent interlayer registration, identify the equivalent 4_5 frames so that the signed interlayer map is −2 I4; choose the same selected tetrahedral orientation on both 20-face layers, with canonical URT rail gap Δ=3/20−(80/81)π/(13φ). This is a **conditional cross-dimensional composition**, not yet derived as the unique physical URT action. Its Hermitian 16D model is

    H16 = [[Lhid+Δ W, C], [Cᵀ,Lhid+Δ W]],
    Lhid=diag(3 I4,5 I4), C=diag(0 I4,−2 I4).

In the A4 singlet k²=3/5 and triplet k²=1/15, the eigenvalues are EXACTLY

    3±Δ√(3/5)                 (singlets),
    5±√(4+3Δ²/5)              (singlets),
    3±Δ/√15                   (each threefold),
    5±√(4+Δ²/15)              (each threefold).

At Δ=0.002489189840420375, the resonant first-order shifts are ±0.00192811815949936 for the singlet and ±0.000642706053166454 for the triplet: **an exact 3-to-1 amplitude ratio**. Direct diagonalization of the 16×16 block matches the radicals to 3.997×10⁻¹⁵. All 16 eigenvalues are positive, so this finite Hamiltonian admits a positive Gibbs or squared transfer with no instability.

**What is derived:** exact resonance and a parity-odd tetrahedral mixing with singlet/triplet 3:1 splitting on a source-defined finite operator. **What is conditional:** identifying the 600-cell A4 breaking gate with the 6D cube's particular 20-face orbit in a coherent common frame; assigning its amplitude precisely Δ in the physical selected-history transfer; identifying the resonant eigenvalues with on-shell Dirac particle masses.

## 5. Consequence for the actual physics program

The full chain of distinct operator roles is:

    4D 600-cell (2I)
      -> five 24-cells (2T), A5→A4 tetrahedral selection
      -> local ico 12-face20 incidence, hidden 4_3⊕4_5
      -> exact chirality-odd W with A4 singlet/triplet splitting
      + 6D hypercube's strength-2 interlayer hidden transport
      -> energy-3 resonance and first-order Δ splitting
      -> URT chronological π/e,2π/φ² transport to select chiral orientation and reduce A4→C3
      -> established 13-stage wall, Y24/D48 currents
      -> physical pole residues, masses, CKM/PMNS (requires independent identification).

The **threefold triplet remains degenerate** in the A4-symmetric model. An A4-equivariant Hermitian operator acts as a scalar on an irreducible single triplet, so the present calculation by itself cannot produce three distinct charged-lepton masses or Koide Q=2/3. The established URT history must provide an independent A4→C3 (or stronger) oriented splitting operator, and it must satisfy the exact physical current and pole dictionary. The existing September L=13 Y24/D48 wall results are preserved; the current geometric calculation does not retune or replace them.

## Independent verification

Run `python combined_coset_audit.py` (NumPy, SciPy, SymPy, NetworkX; includes the source `600_cell_cathedral_local_audit.py`). It constructs all 120 quaternions, enumerates the five subgroups' cosets, generates the A4 actions and exact face orbits, forms rational orthogonal projectors, proves the minimal polynomial and chiral anti-commutator *exactly*, then directly diagonalizes the two-layer operator. Machine-readable output `cross_dim_operator_results.json`. No GitHub write or modification performed.
