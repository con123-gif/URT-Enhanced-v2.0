#!/usr/bin/env python3
"""No-fit first-principles sufficiency test for Oct 21 Cathedral H16.
Uses only the archived exact 16D eigenvalue formulas. No experimental masses.
The geometric coset/projector computation is independently reproducible by
`combined_coset_audit.py` included with this audit.
"""
from itertools import combinations
from math import sqrt, pi, sin, cos
import json
from pathlib import Path
phi=(1+sqrt(5))/2
Delta=3/20-(80/81)*pi/(13*phi)

def spectrum(g):
    values=[]
    for ksq,mult in ((3/5,1),(1/15,3)):
        levels=(3-g*sqrt(ksq),3+g*sqrt(ksq),5-sqrt(4+g*g*ksq),5+sqrt(4+g*g*ksq))
        values.extend([v for v in levels for _ in range(mult)])
    return sorted(values)

def Q(x): return sum(v*v for v in x)/(sum(x)**2)

def exhaustive(g):
    eig=spectrum(g)
    pairs=[(Q([eig[i] for i in idx]),list(idx)) for idx in combinations(range(16),3)]
    qmax,indmax=max(pairs)
    m,M=eig[0],eig[-1]
    endpointbound=max(Q((m,m,M)),Q((m,M,M)))
    assert qmax<=endpointbound+1e-14
    return {"coupling_g":g,"eigen_min":m,"eigen_max":M,"max_raw_koide_Q":qmax,
            "maximizing_indices":indmax,"maximizing_root_candidates":[eig[i] for i in indmax],
            "continuous_interval_Q_upper_bound":endpointbound,"full_eigenvalues":eig}

# C3 commutant identity: X=a I+b(S+S^T)+i c(S-S^T)
# eigenvalues are a+2b, a-b+sqrt(3)c, a-b-sqrt(3)c
# thus Tr X=3a and Tr X²=3a²+6(b²+c²)
# Exact Koide Q=2/3 iff b²+c²=a²/2.
def c3_roots(a,b,c):
    return [a+2*b,a-b+sqrt(3)*c,a-b-sqrt(3)*c]
for a,b,c in ((2,0.3,0.5),(1,1/(2*sqrt(2)),sqrt(3)/(2*sqrt(2)))):
    assert abs(Q(c3_roots(a,b,c))-(1/3+2*(b*b+c*c)/(3*a*a)))<1e-14

models=[exhaustive(g) for g in (0,Delta,.01,.1,1)]
result={"date":"2026-10-23","geometry_verified_by":"combined_coset_audit.py",
 "phi":phi,"Delta":Delta,"exact_coset_mixing_singular_values":[sqrt(3/5)]+[1/sqrt(15)]*3,
 "exact_interlayer_hypercube_coupling":2,
 "first_order_resonant_singlet_split":Delta*sqrt(3/5),
 "first_order_resonant_triplet_split":Delta/sqrt(15),
 "resonant_split_ratio":3.0,
 "root_mass_interpretation":"Conditional direct identification only; not the microscopic physical mass map",
 "c3_koide_algebra":"Q=1/3+2*(b^2+c^2)/(3*a^2); Q=2/3 iff b^2+c^2=a^2/2",
 "family_of_symmetry_compatible_couplings":"g W for real g; geometric group theory alone does not select g=Delta",
 "parameter_sensitivity":models,
 "conclusion":"The exact current H16 spectrum cannot yield Koide from any three raw positive eigenvalues at g=Delta. Requires a physical pole map plus dynamically selected C3 splitting and modulus."
}
out=Path(__file__).with_name('first_principles_gate_results.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print('Delta',Delta)
print('3-to-1 resonance splitting',result['first_order_resonant_singlet_split'],result['first_order_resonant_triplet_split'])
for m in models:print('g=',m['coupling_g'],'max direct Q=',m['max_raw_koide_Q'],'interval bound=',m['continuous_interval_Q_upper_bound'])
print('C3 Koide iff b^2+c^2=a^2/2 confirmed')
print('Saved',out)
