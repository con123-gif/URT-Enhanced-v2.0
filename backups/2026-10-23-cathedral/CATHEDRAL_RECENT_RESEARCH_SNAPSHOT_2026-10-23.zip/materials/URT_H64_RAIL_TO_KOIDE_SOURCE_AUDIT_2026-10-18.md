# Newton's Cathedral / URT — source-level rail-to-Koide calculation (18 October 2026)

## Status
**Executed**, not an assumption-only proposal. Uses the genuine original Oct 8 `golden_species_operators.npz` with SHA256 `9bfd183c01b43e3a589917f334ec5758cefb912cf30f55147b58ccb496b0399b` and the signed-history `combined_signed_source_operators.npz` from the 17 Oct recovered handoff. No charged-lepton masses or empirical Koide phase are supplied to any calculation. No existing Cathedral closure is globally reopened by these local operator tests.

**Results:** (i) the original H64 source has a parity-protected, exactly even hidden-five coupling and a nonzero, analytically predictable O(Delta^2) response; (ii) composing the archived coupling with the existing uniform URT rail flow changes the native three-pole generalized phase by `-5.19111921e-7` rad and native root-Koide Q by `+1.37850397e-7`; (iii) the dressed native Q is `0.5370368460413`, not 2/3, and the dressed generalized phase is `0.4274263153087`, not the mass-inferred `0.22222204707`; (iv) the original 18D signed-history action has nontrivial *quadratic* holonomies for certain modes but zero holonomy at its lowest Hessian mode. No unique photon/history-to-charged-pole selector follows from these inputs.

## 1. Explicit URT rail flow
The existing 13-site flow in the *uniform* sector (graph Laplacian annihilates the uniform state) is

    d_{t+1} = d_t - [1/(8 pi)] (phi-1)(d_t-d_star)(1+d_t^2),
    d_0=3/20,
    d_star=(80/81) pi/(13 phi),
    Delta=3/20-d_star=0.0024891898404204027.

This iterates the actual URT fixed-point flow. It does **not** already supply a map from a 13-component detuning vector into the 18D signed-history field or a mass-pole operator. For the test, compose its *scalar gap* `Delta_t=3/20-d_t` with the source-certified H64 hidden-5 update as specified below. This is an explicit, distinguished **conditional composition**, not a newly proven microscopic time evolution of H64.

## 2. Exact source reduction and parity
The archived electron H64 positive operator `K_cross` and the baseline `K_base` obey

    K_cross - K_base = w w^dagger, rank 1;

rank-one residual `4.3392e-15`. Its excited hidden quartet projection `w5=P5 w`, `P5=Qminus Qminus^dagger`, satisfies

    ||w5||^2 = [486/(25 phi^2)] Delta^2 = 4.600838826238046e-5.

Source norm versus the displayed exact expression agrees to better than `1e-18` absolute. `P5` commutes with `K_base` (Frobenius error `2.53e-15`); the archived selected generation3 frame lies in the +1 eigenspace of the reflection `J=I-2 P5` (error `3.98e-16`). Therefore

    J K(Delta) J = K(-Delta),
    K(Delta)=K_base+[w_rest+(Delta/Delta_star)w5]
                         [w_rest+(Delta/Delta_star)w5]^dagger,

where `Delta_star` denotes the physical fixed rail gap, to avoid confusing it with the 13-site fixed point `d_star`. The tested reflection residual is `1.79e-14`. Eigenvalues and selected-generation spectral invariants are even functions of the coupling-gap variable, with no linear term.

Original H64 has an exact 14-dimensional invariant block (leakage `7.99e-15`); the source's electron active 4x4 sector is

    H4=diag(g1,g2,3,5)+u u^T,
    (g1,g2)=(0.7822507311068735,3.551149519739926),
    u=(0.8556003207749434,1.248897176948704,
       sqrt(6)/phi,(9/5)*Delta*sqrt(6)/phi).

The four active roots satisfy the *source-derived secular equation*

    F(z,Delta)=1 - u1^2/(z-g1)-u2^2/(z-g2)
                 -u3^2/(z-3)-[486/(25 phi^2)]Delta^2/(z-5) = 0.

At Delta=0, the light active root is approximately `1.044258151238` (other two selected poles are independent spectators). Implicit differentiation in `Delta^2` yields

    d z/d(Delta^2) |0 = [486/(25 phi^2)] /
      [(z0-5)*sum_{i=1}^3 u_i^2/(z0-g_i)^2]
      = -0.16306897291135.

Leading light-pole displacement: `-1.01038612876e-6`; **exact**, direct 64x64 displacement: `-1.01038229672e-6`. Thus the scale and sign are actual source consequences, not a fitted division by 36.

## 3. Full actual 64x64 charged poles over the URT history
For each URT iterate t, define `K_t=K_base+(w_rest + [Delta_t/Delta] w5)(...)^dagger`. Diagonalize the *64x64* source and select the three eigenstates with the largest weight in the unchanged archival electron generation3 frame `generation6_frame @ e_lower_frame`. The selected original poles at the physical source have residues `(1,0.92638850999,1)` and values

    (0.116918003428821,1.044257140855608,2.343665940468388).

Conditional on interpreting these positive source eigenvalues as square-root masses, define

    Q=sum_i lambda_i^2/(sum_i lambda_i)^2,
    r=sqrt(6*(Q-1/3)),
    theta=atan2(sqrt(3)*(lambda_2-lambda_1),
                2 lambda_3-lambda_1-lambda_2).

These are algebraic spectrum diagnostics, **not** an asserted identification with observed charged-lepton masses.

| URT step | detuning d_t | Q_native | theta_native (rad) |
|---:|---:|---:|---:|
| 0 | 0.150000000000 | 0.537036708191 | 0.427426834421 |
| 13 | 0.149298525067 | 0.537036719138 | 0.427426793195 |
| 36 | 0.148506244064 | 0.537036757833 | 0.427426647479 |
| 100 | 0.147706071451 | 0.537036825263 | 0.427426393556 |
| 200 | 0.147526136817 | 0.537036844349 | 0.427426321682 |
| 500 | 0.147510817573 | 0.537036846040 | 0.427426315312 |
| 1000 | 0.147510810160 | 0.537036846041 | 0.427426315309 |

At the fixed-point endpoint:

    Delta Q=+1.37850396764e-7,
    Delta theta=-5.19111921060e-7 rad,
    Q=0.537036846041,
    r=1.105541078499,
    theta=0.427426315309 rad.

The proposed empirical Koide phase shift is approximately `-1.75149149e-7` rad from 2/9, while the earlier screening *formula* gives `-1.75311721e-7`. Neither equals this native source derivative. The implicit secular-equation coefficient produces `Delta theta/Delta^2 = -0.08378121` at leading order, as opposed to the screening postulate's coefficient `-4/(45pi) = -0.0282942121`. Matching the latter requires an independently derived new operator/action, not relabeling the H64 source response.

## 4. The 13-mode QR and the 4+9 interface
The positive-diagonal QR of `U_nk(d)=exp(2pi i d n k/13)` is unitary; optional column phases are appended *after* QR. Transforming the same archived 13-retained source operator by `Q(d)` is unitary conjugation. Results:

| Input d | native 4x9 basis interface Frobenius norm | retained-13 spectrum discrepancy |
|---|---:|---:|
| d_star | 2.992796066898 | 3.9e-15 |
| d_cl | 2.993526457985 | 3.2e-15 |

These changing matrix-element norms do **not** mean the physical H64 mass poles change under QR. QR coordinates and the URT *actual dynamical* source perturbation must be distinguished. The 4-d QR subspace projects onto the source archival electron generation3 with trace overlap only `0.95189178` at d_star (not a fully established generation identification).

At real off-spectrum energy `z=-0.1` the full 64-to-3 source Schur effective operator has gauge-invariant triangle-product phase `-3.6e-19 rad`, versus noncirculant residual `1.52378`; it is real to numerical precision and is not the desired 3-cycle Koide holonomy. The transformed basis phases do not change the selected spectral invariants.

## 5. Independent 18D selected-history quadratic phase probe
The original 18D signed-history source has a positive Hessian. For a normalized Hessian eigenvector `h_j`, perturb the original twelve 3x3 link amplitudes *without fitting* by `A_{k} -> A_k + Delta sum_i dA_{k,i} h_{j,i}`, and recompute the ordered polar return. At the selected state the return is I3, norm residual `4.98e-15`.

The unique lowest Hessian eigenmode (`lambda=2.44623025112`) gives eigenphases <= `1.3e-15` rad at Delta displacement: no holonomy. Other Hessian modes produce nontrivial and source-defined *quadratic* SU3 eigenphases; the largest absolute phase among all 18 single normalized eigenmodes is `5.47e-6` rad. Some stiffer modes produce ~`1.718e-7` rad phases, but neither the Higgs/Klein quartet/URT dynamics nor this dataset provides a uniquely defined map from those SU3 eigenphases to the physical charged-lepton root-mass circulant. Agreement of scale is not a Koide prediction.

This agrees with the already recovered analytic 18D first-derivative cancellation, and advances it by checking every Hessian eigenmode at the *native* rail amplitude.

## 6. Action-origin amplitude question
For a separately specified positive-circulant toy action

    Gamma=(kappa/2)Tr(M^2)-ln(v)-ln|s|,
    M=vI+sC+s*C^dagger,

stationarity gives `v^2=1/(3kappa)`, `|s|^2=1/(6kappa)`, hence root-cosine amplitude `r=2|s|/v=sqrt(2)` and Koide Q=2/3 **independent of phase**. This is a correct algebraic conditional derivation, but this action has not been derived as the root-mass effective action of the recovered H64 source; the actual original selected source gives `r=1.105541...`. The action neither selects theta nor supplies the missing source-to-physical-pole identification.

## Clear status and next exact mathematical object
**Proved/tested for the archived source:** rank-one update, analytic parity-even `Delta^2` coefficient, nonzero and numerically executed conditional URT-to-H64 rail response, 64x64 source pole invariants, zero native 3-loop phase in the archived physical generation frame, and existence of source-level 18D quadratic holonomies.

**Not established by this source:** a unique URT boundary map from the 13 detuning stages to the 18D signed-history fluctuation direction; an oriented photon/current insertion fixing one 3-cycle holonomy and its normalization; equality of the physical three root-mass operator to the separate circulant toy action. A formula based only on 36 interface-pair counting and an unpaired ninth exhaust mode is not present in the original source, and would be a new ansatz rather than a derivation.

This is a **local model status**, not a no-go theorem for URT or for the multiple-Platonic Cathedral.

## Reproduce
With Python, NumPy and SciPy, run `python urt_h64_rail_source_test.py golden_species_operators.npz`; output `urt_h64_rail_source_results.json`. Run `python h64_hessian_history_probe.py` after placing `combined_signed_source_operators.npz` at the location accepted by that script; output `h64_hessian_history_results.json`. Source matrices are untouched, SHA above. Zero measured masses enter either script.
