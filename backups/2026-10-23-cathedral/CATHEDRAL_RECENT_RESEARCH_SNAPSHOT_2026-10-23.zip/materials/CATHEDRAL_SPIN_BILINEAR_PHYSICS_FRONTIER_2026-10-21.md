# Newton's Cathedral — binary-icosahedral bilinear interface to gauge currents and matter

**Date:** 21 October 2026. **Mode:** chat-first, no fitting, no writes to GitHub. This audit independently executes the 600-cell spin connection and the SHA256-verified September 5 frozen Cathedral v32 `L=13` response-wall model. It does **not** supersede subsequent v35+ corrections or the separate October H64 selected-history programme.

## 1. The exact representation-theoretic emergence of the 16-channel response

The 600-cell's 12 nearest-neighbour icosahedral shell vertices, each carrying the fundamental `2I` spinor, define a 24D spinorial carrier. Its complex 2I decomposition is

`H_shell_spin = 2 (2 ⊕ 4_s ⊕ 6_s)`.

The full 120-element binary icosahedral group covariance of the shell connection was checked numerically to **1.322e-15** Frobenius norm. Its central `-1` acts as `-I24` with exactly zero error. The discrete shell spinor Laplacian has eigenlevels and degeneracies

| Eigenvalue | Degeneracy |
|---:|---:|
| 0.0202034302 | 2 |
| 2.3713444394 | 2 |
| 2.9737786871 | 4 |
| 5.7265425280 | 4 |
| 6.1755705046 | 6 |
| 7.2270327288 | 6 |

Thus the representations 2 and 6 each occur twice in the 24 shell, making an 8D source `2⊕6` available but **not uniquely selected**: one must still select its multiplicity copy by the actual URT transfer, not by matching the number eight.

Clebsch–Gordan under the binary icosahedral group gives

`2 ⊗ 2 = 1 ⊕ 3`,

`2 ⊗ 6 = 3' ⊕ 4 ⊕ 5`.

Therefore exactly

`2 ⊗ (2 ⊕ 6) = 1 ⊕ 3 ⊕ 3' ⊕ 4 ⊕ 5`.

This is the *same A5 representation content* as the 16D Cathedral response `4_geometry ⊕ 1_Y ⊕ 3_W ⊕ (3'⊕5)_color`. The spinorial minus signs cancel, so all 16 output channels are ordinary A5 representations. The five irreducible A5 character values of this tensor representation are precisely `(16,0,1,1,1)` on identity/order2/order3/order5A/order5B classes; their inner products with all five A5 irreducible characters equal 1, with no fitted coefficients. Independently, `6=Sym^5(2)` and under ordinary SU2 tensor fusion `2⊗6` consists of spin-2 and spin-3 harmonics; upon restriction to A5, spin2->5 and spin3->3'+4.

**Physical significance:** this gives an explicit spin-bilinear route from exceptional 600-cell geometry to the entire 16-channel response representation. It is not merely a dimension coincidence. The factor 2 is a *spatial spinor*, not automatically a weak-isospin doublet. Its conversion to an **internal** gauge connection is still a physical identification to be derived.

## 2. Genuine matrix Lie brackets, not just dimensions

Let `A` denote the real skew-symmetric traceless 3x3 matrix space (dimension 3'), and `S` denote `i` times the real symmetric traceless 3x3 space (dimension 5). Both are anti-Hermitian and traceless. Direct matrix calculation proves

`[A,A] subset A; [A,S] subset S; [S,S] subset A`.

The three maximum Frobenius closure residuals from all basis-generator commutators are `3.14e-16`, `7.25e-16`, `6.28e-16`. This is a concrete construction `su(3)=so(3')⊕i Sym_0(3')=3'⊕5`. Separately, the three traceless anti-Hermitian Pauli matrices span `su(2)` with commutator closure error `1.93e-16`. The scalar singlet supplies a `u(1)` factor. Thus one can construct the full **Lie algebra** `u(1)⊕su(2)⊕su(3)` on the 12 non-geometric channels in agreement with the Cathedral's gauge-module dictionary. No continuous coefficient was fitted.

**Limit:** algebra closure does **not** derive local gauge redundancy, vector-boson dynamics, an internal/spatial SU2 distinction, physical chiral charges, couplings, or an interacting Yang–Mills action.

## 3. There is a strict spinor-versus-flavour selection rule

A bare 24D binary-icosahedral spinor shell carries the central character `-1`, while an ordinary 24D A5 matter flavour module pulled back to 2I carries central character `+1`. Any 2I-equivariant linear map `F` between these carriers obeys `F(-I)=(+I)F`, implying `F=0`. **A direct linear spin-shell ↔ flavour identification is forbidden**. Bilinears or tensor-product fermion fields have the correct central parity. This is why a bare `24=24` dimensional identification would have been a spurious particle model.

## 4. Executed 600-cell spin lift of the pre-existing v32 physical response

The exact original source was verified against the canonical SHA256 `12ca02d35f8847d5d424aa407b75ff7886db45fa28848ea70cf2164a55f3a18e`, and all existing v32 13-step nearest-history-wall Schur-complement checks passed.

Take a 13-vertex nearest-neighbour path of the 600-cell icosahedral vertex star and put its **native** geodesic spin link `V_k ∈ SU2` on each of the 12 wall-history links. With the unchanged 24-state Cathedral links `L_k`, the minimal covariant tensor lift has per-link operator `V_k ⊗ L_k`. Its endpoint is identically

`Y48 = W_spin ⊗ Y24`, with `W_spin = V12...V1 ∈ SU(2)`.

Then `Y48†Y48=I2⊗Y24†Y24`, so **every original response mass is preserved and doubled for spin**. The extracted charged-current residues obey

`(W⊗U_L)† (I2⊗J_ud) (W⊗U_L) = I2⊗(U_L† J_ud U_L)`.

This is a genuine connection to the earlier *weak-current* calculation, not a fresh 24D mass ansatz. Numerical tests:

- Full 13-wall v32 checks: PASS.
- Wilson-chain unitarity residual: `1.91e-15`.
- Lifted `Y48` right-Gram identity: `3.16e-15`.
- Absolute doubled-mass spectrum residual: `9.99e-16` (tiny `1e-20` neutrino entries protected algebraically rather than trusted to SVD relative accuracy).
- Lifted weak-current residue identity: `5.66e-15`.
- CKM reconstructed from spin-lifted weak current versus original CKM maximum absolute entry error: `1.55e-15`.

The historical v32 charged-lepton Koide diagnostic is `Q_e=0.6662339185751964` and remains the same under this spin lift. **A universal spatial spin connection cannot change this to `2/3` or generate particle mass hierarchies by itself.** This refers to the recovered historical v32 model, not a conclusion about later URT refinements.

The choice to associate one geometrical 13-vertex Hamiltonian path with the original 13 chronological wall layers is explicitly a **conditional candidate identification**, not a proven property of URT's history selection. For *any* unitary spin chain, the mass/current invariance is an exact theorem.

## 5. A geometric effect survives the physical weak-current bridge: two-path interference

For a triangular geodesic face, the two spinor amplitudes between the same endpoints (direct edge versus two-edge detour) differ by gauge-invariant Wilson holonomy with spin eigenphase

`theta = (3 acos(1/sqrt(5))-pi)/2 = 0.089926749896239 rad`.

The spin-unpolarized interference contrast is

`cos(theta)=0.995959313953112`.

For **equal coherent path amplitudes**, `U_+ = (U_direct+U_detour)/2`, the spin-averaged weak charged-current transition probability is exactly

`P_ij(constructive) = [(1+cos(theta))/2] |V_ij|² = 0.997979656976556 |V_ij|²`.

An equal-amplitude antisymmetric combination instead yields `[(1-cos(theta))/2] |V_ij|² = 0.002020343023444 |V_ij|²`. For the historical v32 CKM input, this gives `|Vus|²: 0.050313763967364 -> 0.050212112905349` for the constructive two-path experiment. There are no mass or mixing fitting parameters in this *conditional* two-path calculation.

This is a **physical scattering-amplitude consequence** of the finite curved connection if the physical URT transfer indeed superposes these paths coherently and has the specified normalisation. Neither the existence of the required microscopic two-path current nor its experimental realisation has yet been established. It is not a prediction of a correction to standard weak decay rates in ordinary laboratory spacetime without that identification.

## 6. Actual next dynamical matching, without reopening earlier closures

The geometry now supplies the 24D spinor shell, a source of 16-dimensional response bilinears, a closed candidate `u1+su2+su3` matrix algebra, a covariant fermion/spin interface, and an exact Wilson-current interference observable. None of this automatically selects a unique **physical** gauge connection or Koide masses. The missing object is no longer a mysterious numerical coefficient; it is an explicit selected-history vertex map

`V_URT : H_history -> Hom_2I(H_spin ⊗ H_spin^*, H_geometry ⊕ H_gauge ⊕ H_matter)`

that picks *which* eight spinorial modes and *which* matrix-gauge-bilinear channels couple to the old H64 Feshbach self-energy and Y24 wall mass operator. That map must come from the original URT positive transfer/source tensors, not postulated from experimental masses. Its interacting current vertex must satisfy gauge Ward/Slavnov–Taylor identities if it is to represent nature.

Preserve v35 wall-current finite residue closure, all earlier URT H64 mathematical closures, and the October exact 600-cell geometry without changing their evidential status. A claimed physical identification should be judged by independently generated mass poles and amplitudes, not by representation dimensions alone.

## Reproduction

Run `python spinor_bilinear_gauge_audit.py` (NumPy/SymPy) and `python urt_600cell_wall_spin_interface.py` (NumPy/SciPy/NetworkX). The source freeze is verified by SHA256 before calculating. The ZIP includes the original v32 source, unchanged, its precise geometry inputs and both new executable scripts and results. GitHub was **not accessed or updated** for this calculation.
