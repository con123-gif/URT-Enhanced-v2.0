# Newton's Cathedral — joint quark H64 history-field variational calculation

Date: 18 October 2026. Independent direct execution with the untouched October 8 source binary `golden_species_operators.npz` (SHA256 `9bfd183c01b43e3a589917f334ec5758cefb912cf30f55147b58ccb496b0399b`). No observed quark masses, CKM data or desired Koide values were used in operator construction, minimization or diagnostics. The action is the original **conditional** common-vacuum log-determinant probe of `shared_species_vacuum.py`, restricted to u,d; it is NOT an established maximized physical entropy action and not yet a derived H64 Standard-Model mass functional.

## Native source and one common 13D history variable

Let `phi=(1+sqrt(5))/2`, `alpha=phi^-2`, `F=[F5 Qplus Qminus]` the archived orthonormal 64x13 source chart, `L=affine_L_plus` the archived 9x64 complex decoder, `C_i=reshape((L F)^T)[i]` for `i=0..12`, and `S_u,S_d` the archive's primitive complex 3x3 species amplitudes. The single shared history coordinate `x` determines *both* species source matrices:

    A_f(x,s_f) = S_f (1+s_f) + sum_{i=0}^{12} x_i C_i,
    M_f(x) = [[I_3,A_f†],[A_f,0_3]],
    Q_f(x)=alpha I_6+M_f(x)^2 > 0.

The fixed colour weights are 3 and 3, with quark-only functional

    Gamma(x,s_u,s_d)=alpha ||x||²/2 + (3/2) log det Q_u(x,s_u)
                                      + (3/2) log det Q_d(x,s_d).

All entries in the source and the coefficient are fixed before solution. The sign/normalization of this positive determinant completion and potential are **conditional prior assumptions**, not proven to follow uniquely from the URT-selected microscopic path measure. In particular `Gamma` is not by definition the Shannon/von Neumann entropy of the two root-mass operators.

## Exact stationary equations and mixed response

Write `R_f=Q_f^-1`, `Q_f,i=∂Q_f/∂x_i`, and `Q_f,ij=∂²Q_f/(∂x_i∂x_j)`:

    ∂_i Gamma = alpha x_i+(3/2) sum_f tr(R_f Q_f,i) =0,
    H_ij = alpha delta_ij + (3/2) sum_f
           tr(R_f Q_f,ij - R_f Q_f,i R_f Q_f,j).

At fixed x the two source load parameters are independent, hence `H_{s_u,s_d}=0`. Relaxing the common 13D field yields, without an inserted cross-coupling coefficient,

    ∂² Gamma_eff/(∂s_u ∂s_d)
       = H_su,sd - H_su,x H_xx^-1 H_x,sd
       = -0.867190411068071.

The *induced interaction* is not zero. Finite-difference minimization of all four source-sign combinations at ±2e-4 verifies `-0.867190869113799` (absolute difference 4.58e-7). This calculation is the explicit common-history Schur complement previously requested.

## Numerical output

Common stationary x: `||x||=0.374531261456179`; `Gamma=3.09085704085617` (without spectator constants); gradient residual `1.85e-15`, Hessian eigenvalue min/max `0.640631099 / 9.069611849`. All eight deterministic starting fields checked in an independent run converged to the same local stationary state to numerical tolerance. The 13x2 history-to-quark-source mixed response has rank 2 and singular values `2.359824001`, `0.202370676`.

For the specified **conditional** common-left 3D root-Yukawa dictionary `X_f=sqrt(A_f† A_f)`, not measured physical mass poles:

| invariant | joint vacuum | independently stationary u or d sector |
|---|---:|---:|
| Q_u | 0.49642883094 | 0.41550383738 (u-only) |
| Q_d | 0.49622268514 | 0.39965297017 (d-only) |
| Q_ud | 0.49165619495 | n/a |
| Q(X_u+X_d) | 0.49401483586 | n/a |
| Tr(X_d)/Tr(X_u) | 0.84945772475 | n/a |
| ||[X_u,X_d]||_F | 0.01776687149 | n/a |
| ||[X_u/TrX_u,X_d/TrX_d]||_F | 0.00441742215 | n/a |

Underlying singular-value spectra (u): `(0.01212119524,1.01392452478,1.14991044980)`; (d): `(0.01210277201,0.85014892917,0.98613107599)` in arbitrary source units. Thus the native quark-only common vacuum indeed couples the operators and breaks their simultaneous diagonalization; it **does not** yield `Q_u≈0.849`, `Q_d≈0.731`. The asserted strict uplift above `2/3` is not a theorem of shared flavour space. The common vacuum changes these ratios upward compared with the separately minimized instances for this particular dictionary, but not to the empirical values.

As a separate source-spectrum diagnostic, the three smallest eigenvalues of the *native* 6x6 Q_f give root-eigenvalue Koide diagnostics `0.34453225252` (u), `0.33952697872` (d). These are also not physical quark pole predictions. Different source-to-mass dictionaries are quantitatively inequivalent; their selection must be derived rather than chosen by observed accuracy.

## What this proves, and exactly what it does not

1. The **existing archived conditional H64/URT action** has one shared 13-component history field coupling u and d even though their primitive sources enter additively. Its induced mixed response has a computable nonzero coefficient derived analytically and checked by finite differences. This is progress on the requested common-flavour-operator construction.
2. The fixed action's quark-only local minimum does not force the individual positive Yukawa-root operators to satisfy quark Koide numbers or `Q>2/3`. This is a limitation of the tested completion/dictionary, **not** a universal no-go for the full URT, all-Platonic hidden sectors, or the previously recovered phenomenological flavour branch.
3. A genuine derivation of empirical quark masses requires the original H64 physical mass-pole map and an actual SU(2)_L-covariant common left-handed photon/Higgs/history action. The logdet Gaussian completion is only one specified probe and cannot be silently renamed "maximum entropy".

## Reproduce

In the same directory as `golden_species_operators.npz`, run `python joint_urt_h64_quark_doublet_audit.py`. It writes full `joint_urt_h64_quark_doublet_results.json` and checks stationary equations and the relaxed Schur mixed derivative numerically. The binary input is unmodified; only NumPy/SciPy are required.
