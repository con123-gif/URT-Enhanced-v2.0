#!/usr/bin/env python3
"""Coupled root-quark positive matrices: basis-invariant numerical and theorem audit.

This program treats six *quoted mixed-scale illustrative masses* as inputs,
not same-scale running Yukawa masses. CKM: PDG global fit 2025, s12=.22501,
s13=.003732, s23=.04183, phase=1.147 (in radians).
No URT prediction, optimization or target fit is performed.
"""
import json
from math import sqrt, sin, cos, log, pi
import numpy as np

m_up=np.array([2.16,1270.0,172690.0]);m_down=np.array([4.67,93.4,4180.0])
s12,s13,s23,phase=.22501,.003732,.04183,1.147
c12,c13,c23=(sqrt(1-v*v) for v in (s12,s13,s23))
V=np.array([
[c12*c13,s12*c13,s13*np.exp(-1j*phase)],
[-s12*c23-c12*s23*s13*np.exp(1j*phase),c12*c23-s12*s23*s13*np.exp(1j*phase),s23*c13],
[s12*s23-c12*c23*s13*np.exp(1j*phase),-c12*s23-s12*c23*s13*np.exp(1j*phase),c23*c13]
],dtype=complex)
I3=np.eye(3)
u=np.sqrt(m_up);d=np.sqrt(m_down)
X_u=np.diag(u);X_d=V@np.diag(d)@V.conj().T
S_u=float(np.trace(X_u).real);S_d=float(np.trace(X_d).real); kappa=S_d/S_u
Q_u=float(np.trace(X_u@X_u).real/S_u**2)
Q_d=float(np.trace(X_d@X_d).real/S_d**2)
I_ud=float(np.trace(X_u@X_d).real);Q_ud=I_ud/(S_u*S_d)
uhat=X_u/S_u;dhat=X_d/S_d
A=uhat-I3/3;B=dhat-I3/3
C=np.array([[float(np.trace(A@A).real),float(np.trace(A@B).real)],
            [float(np.trace(B@A).real),float(np.trace(B@B).real)]])
G=np.array([[Q_u,Q_ud],[Q_ud,Q_d]])
Q_total=float(np.trace((X_u+X_d)@(X_u+X_d)).real/(S_u+S_d)**2)
max_overlap=float(np.dot(np.sort(u),np.sort(d)))
assert np.linalg.norm(V.conj().T@V-I3)<1e-12
assert I_ud <= max_overlap+1e-8
assert np.min(np.linalg.eigvalsh(C))>=-1e-12
assert abs(np.trace((uhat-dhat)@(uhat-dhat)).real-(Q_u+Q_d-2*Q_ud))<1e-12
assert abs(Q_total-(Q_u+2*kappa*Q_ud+kappa*kappa*Q_d)/(1+kappa)**2)<1e-12

def gram_entropy(T):
    eigenvalues=np.linalg.eigvalsh(T)
    probs=eigenvalues/eigenvalues.sum()
    return float(-sum(p*log(p) for p in probs if p>0))

# Counterexample: Q(X)=Q(Y)=2/3 although [X,Y]!=0.
# For (1,2,t), Q=2/3 exactly when t=6+sqrt(39).
t=6+sqrt(39)
X=np.diag([1.0,2.0,t]);angle=pi/4
R=np.array([[cos(angle),-sin(angle),0],[sin(angle),cos(angle),0],[0,0,1]])
Y=R@X@R.T
QQ=lambda Z: float(np.trace(Z@Z).real/np.trace(Z).real**2)
comm=float(np.linalg.norm(X@Y-Y@X))
assert abs(QQ(X)-2/3)<1e-12 and abs(QQ(Y)-2/3)<1e-12 and comm>0

out={
 "inputs_warning":"The six quark masses are mixed-scale mixed-scheme illustrative figures, not a uniform renormalization-scale set.",
 "traces_MeV_sqrt":{"u":S_u,"d":S_d,"ratio":kappa},
 "Koide":{"u":Q_u,"d":Q_d,"ud":Q_ud,"sum":Q_total},
 "cross_trace_MeV":I_ud,"maximum_possible_aligned_cross_trace_MeV":max_overlap,
 "traceless_covariance":C.tolist(),"traceless_covariance_det":float(np.linalg.det(C)),
 "traceless_alignment_cosine":float(C[0,1]/sqrt(C[0,0]*C[1,1])),
 "normalized_Frobenius_squared_distance":float(np.linalg.norm(uhat-dhat)**2),
 "normalized_commutator_Frobenius":float(np.linalg.norm(uhat@dhat-dhat@uhat)),
 "Gram_density_vN_entropy_nats":gram_entropy(G),
 "traceless_Gram_density_vN_entropy_nats":gram_entropy(C),
 "Qsum_equipartition_condition_residual":float((Q_u-2/3)+2*kappa*(Q_ud-2/3)+kappa*kappa*(Q_d-2/3)),
 "explicit_noncommuting_Koide_2over3_counterexample":{
   "X_spectrum":[1,2,t],"Y_spectrum":[1,2,t],"rotation_radians":angle,
   "Q_X":QQ(X),"Q_Y":QQ(Y),"commutator_Frobenius":comm},
 "CKM_abs":np.abs(V).tolist()
}
if __name__=='__main__': print(json.dumps(out,indent=2))
