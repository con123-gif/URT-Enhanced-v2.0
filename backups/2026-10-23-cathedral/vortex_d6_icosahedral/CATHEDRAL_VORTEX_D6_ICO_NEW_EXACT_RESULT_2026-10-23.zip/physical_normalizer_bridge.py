import runpy,contextlib,io,numpy as np
from pathlib import Path
p=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(p/'hypercube_urt_frontier_audit.py'))
with contextlib.redirect_stdout(io.StringIO()):x=runpy.run_path(str(p/'exceptional_sixcycle.py'))
N=64;sigs=d['sigs'];s2i=d['s2i'];A=d['A'];orbits=d['orbits'];phi=d['phi'];
f=x['f'];dd,ss=f
fp=[]
for s in sigs:
 out=np.zeros(6,dtype=int)
 for i in range(6):out[dd[i]]=ss[i]*s[i]
 fp.append(s2i[tuple(out)])
F=np.zeros((64,64))
for a,b in enumerate(fp):F[b,a]=1
assert np.linalg.norm(F.T@A@F-A)<1e-10
assert np.linalg.norm(np.linalg.matrix_power(F,6)@np.eye(64)-np.eye(64)[np.array([s2i[tuple(-s)] for s in sigs]),:])<1e-10
print('F spectral order on 64',[(k,int(np.trace(np.linalg.matrix_power(F,k)))) for k in range(1,13)])
print('F relative to A5 orbit 12,20,20,12 mapping', [[sum(fp[i] in b for i in a) for b in orbits] for a in orbits])
Z=np.zeros((64,16));F_A=d['F_A'];F_B=d['F_B']
for face,cc,m in [(F_A,range(4),'H03'),(F_A,range(4,8),'H05'),(F_B,range(8,12),'H13'),(F_B,range(12,16),'H15')]:Z[np.ix_(face,list(cc))]=d[m]
H=Z@Z.T
print('F hidden16 invariance leakage',np.linalg.norm((np.eye(64)-H)@F@Z))
print('F hidden16 orthogonal norm',np.linalg.norm((Z.T@F@Z).T@(Z.T@F@Z)-np.eye(16)))
print('F mixes spectral4_3 to 4_5 (pair)',np.linalg.norm((Z.T@F@Z)[np.ix_([*range(4),*range(8,12)],[*range(4,8),*range(12,16)])]))
print('F hidden eigenangle',np.round(np.sort(np.angle(np.linalg.eigvals(Z.T@F@Z))),8))
print('F6 on hidden',np.linalg.norm(np.linalg.matrix_power(Z.T@F@Z,6)+np.eye(16)))
# Does F map two cubic 16D blocks via permutation, where icosa 64 repr 4×16?
print('F is commuting with Q6 adjacency norm',np.linalg.norm(F@A-A@F))
# Exact six-fold projective eigenspaces and golden URT chirp: any U=function(F) commutes A and respects hidden H
vals,V=np.linalg.eig(Z.T@F@Z)
# note F_H diagonalizable unitary
print('F commutator with hidden16 native A',np.linalg.norm(Z.T@F.T@A@Z-(Z.T@A@Z)@(Z.T@F.T@Z)))
P=d['projectors']
for k,l in [('3','3prime'),('3prime','3'),('1','1'),('4','4'),('5','5')]:
 print('F conjugates A5 projector',k,'to',l,'residual',np.linalg.norm(F@P[k]@F.T-P[l]))
