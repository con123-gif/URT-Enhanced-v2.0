from pathlib import Path
import runpy,contextlib,io,itertools,collections
from sympy.combinatorics import Permutation,PermutationGroup
import numpy as np
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(p/'hypercube_urt_frontier_audit.py'))
# A5 projected to 6 antipodal axes.
A5=set()
for iso in d['rots']:
 axis=tuple(d['axisof'][iso[a]][0] for a,b in d['axes'])
 A5.add(axis)
assert len(A5)==60
# class of 6-cycles that normalise projected A5
special=[];ordinary=[]
for rest in itertools.permutations(range(1,6)):
 cycle=(0,)+rest
 D=[0]*6
 for j in range(6):D[cycle[j]]=cycle[(j+1)%6]
 inv=[0]*6
 for j,k in enumerate(D):inv[k]=j
 normalizes=all(tuple(D[g[inv[i]]] for i in range(6)) in A5 for g in A5)
 (special if normalizes else ordinary).append(tuple(D))
print('six cycles normalizing A5',len(special),'not normalizing',len(ordinary))
D=special[0]
D2=tuple(D[D[i]] for i in range(6));D3=tuple(D[D[D[i]]] for i in range(6))
print('representative vortex cycle mapping',D,'D² in A5',D2 in A5,'D³ in A5',D3 in A5)
# 5-cycles in A5 and conjugation by D; distinguish conjugacy classes by square
order5=[g for g in A5 if all(g[g[g[g[g[i]]]]]==i for i in range(6)) and any(g[i]!=i for i in range(6))]
print('order5 elements',len(order5))
# A5-conj classes from one element
x=order5[0]
class1=set()
for h in A5:
 invh=[0]*6
 for i,j in enumerate(h):invh[j]=i
 class1.add(tuple(h[x[invh[i]]] for i in range(6)))
class2=set(order5)-class1
print('order5 classes',len(class1),len(class2))
Dx=tuple(D[x[[D.index(i) for i in range(6)][i]]] for i in range(6))
print('D conjugates 5-class1 to class2?',Dx in class2, 'D is outer automorphism?', Dx in class2)
# note scalar 6-cycle D that normalizes unsigned action does not necessarily preserve full signed A5
# but acts on triplets after an induced automorphism of A5
# Full sign-labelled A5 subgroup: calculate whether a signed lift of special D normalizes icos A5 action on 6 signed axes
signedA=set()
for iso in d['rots']:
 dest=tuple(d['axisof'][iso[a]][0] for a,b in d['axes'])
 sgn=tuple(d['axisof'][iso[a]][1] for a,b in d['axes'])
 signedA.add((dest,sgn))
def compose(f,h):
 d1,s1=f;d2,s2=h
 return (tuple(d1[d2[i]] for i in range(6)),tuple(s1[d2[i]]*s2[i] for i in range(6)))
def inverse(f):
 d1,s1=f;dd=[0]*6;ss=[0]*6
 for i in range(6):dd[d1[i]]=i;ss[d1[i]]=s1[i]
 return (tuple(dd),tuple(ss))
normalizing_lifts={}
for dper in special:
 lifts=[]
 for signs in itertools.product((-1,1),repeat=6):
  f=(dper,signs)
  if all(compose(compose(f,g),inverse(f)) in signedA for g in signedA):lifts.append(signs)
 normalizing_lifts[dper]=lifts
print('signed lifts normalizing actual A5: count histogram',collections.Counter(len(x) for x in normalizing_lifts.values()))
if normalizing_lifts[special[0]]:print('sample signs',normalizing_lifts[special[0]][:2])
from sympy.combinatorics import Permutation,PermutationGroup
f=(special[0],normalizing_lifts[special[0]][0]); powf=(tuple(range(6)),tuple([1]*6))
for j in range(1,13):
 powf=compose(f,powf)
 if j in (2,3,6,12):print('F power',j, powf, 'in signed A5',powf in signedA)
# signed axis permutation on 12 endpoints
sgnidx=lambda s:0 if s==1 else 6
def signed_to_12(m):
 dd,ss=m;perm=[0]*12
 for i in range(6):
  perm[i]=dd[i]+(0 if ss[i]>0 else 6)
  perm[i+6]=dd[i]+(6 if ss[i]>0 else 0)
 return Permutation(perm)
signedgroup=PermutationGroup([signed_to_12(g) for g in signedA]+[signed_to_12(f)])
print('FULL A5 + chosen normalizer lift F group order',signedgroup.order())
