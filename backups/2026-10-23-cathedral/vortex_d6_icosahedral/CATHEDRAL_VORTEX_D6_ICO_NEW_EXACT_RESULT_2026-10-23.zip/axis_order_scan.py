from pathlib import Path
import runpy,contextlib,io,itertools,collections
from sympy.combinatorics import Permutation,PermutationGroup
import numpy as np
p=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(p/'hypercube_urt_frontier_audit.py'))
a=d['axes']; axisof=d['axisof'];ro=d['rots']
# permutation on 12 signed endpoints in canonical sign indexing j + 6*s (one of two signs)
A=[]
for iso in ro:
 src=[]
 for idx, (i,j) in enumerate(a):
  for s,v in enumerate([i,j]):
   jx,sg=axisof[iso[v]]
   dst=jx+(0 if sg==1 else 6)
   src.append(dst)
 # src order [axis0+,axis0-,axis1+,axis1-...] different than 0..5,6..11
 out=[0]*12
 for idx in range(6):out[idx]=src[2*idx];out[idx+6]=src[2*idx+1]
 A.append(Permutation(out))
gA=PermutationGroup(A)
assert gA.order()==60
counts=collections.Counter(); examples={}
for rest in itertools.permutations(range(1,6)):
 cyc=(0,)+rest
 out=list(range(12))
 for i in range(6):
  out[cyc[i]]=cyc[(i+1)%6];out[cyc[i]+6]=cyc[(i+1)%6]+6
 D=Permutation(out)
 grp=PermutationGroup(A+[D])
 n=grp.order()
 counts[n]+=1
 examples.setdefault(n,cyc)
print('group orders by 6-cycle coordinate ordering:',sorted(counts.items()))
print('examples:',examples)
