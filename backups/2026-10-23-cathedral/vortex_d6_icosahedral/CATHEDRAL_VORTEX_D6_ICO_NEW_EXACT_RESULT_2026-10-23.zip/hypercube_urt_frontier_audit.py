import numpy as np, itertools, networkx as nx
from scipy.linalg import null_space
phi=(1+np.sqrt(5))/2
V0=[(0,a,b*phi) for a,b in itertools.product((-1,1),repeat=2)]
V0 += [(a,b*phi,0) for a,b in itertools.product((-1,1),repeat=2)]
V0 += [(a*phi,0,b) for a,b in itertools.product((-1,1),repeat=2)]
vec=np.array(V0,float)
G=nx.Graph();G.add_nodes_from(range(12))
for i in range(12):
 for j in range(i+1,12):
  if abs(np.linalg.norm(vec[i]-vec[j])**2 - 4)<1e-8:G.add_edge(i,j)
assert all(x==5 for _,x in G.degree())
opposite={i:int(np.argmin(np.linalg.norm(vec+vec[i],axis=1))) for i in range(12)}
axes=[]
for i in range(12):
 if i<opposite[i]: axes.append((i,opposite[i]))
print('axes',axes)
axisof={i:(a,sg) for a,pair in enumerate(axes) for i,sg in zip(pair,(1,-1))}
rots=[]
for iso in nx.algorithms.isomorphism.GraphMatcher(G,G).isomorphisms_iter():
 M=np.linalg.lstsq(vec,vec[[iso[i] for i in range(12)]],rcond=None)[0]
 err=np.max(np.abs(vec@M-vec[[iso[i] for i in range(12)]]))
 if err>1e-8:raise ValueError(err)
 if np.linalg.det(M)>0:rots.append(iso)
assert len(rots)==60
print('rotations',len(rots))
# s contains signs at selected axis representative; x[axis]=+1 corresponds to the selected positive vertex
sigs=np.array(list(itertools.product((-1,1),repeat=6)),int)
s2i={tuple(s):i for i,s in enumerate(sigs)}
perms=[]
for iso in rots:
 pairs=[axisof[iso[a]] for a,b in axes]
 # image from s source along each axis to target axis j multiplied by sign
 def apply(s):
  out=np.zeros(6,int)
  for a,(j,sg) in enumerate(pairs):out[j]=sg*s[a]
  return s2i[tuple(out)]
 perms.append([apply(s) for s in sigs])
perms=np.array(perms,int)
# components of orbit partitions
unseen=set(range(64));orbits=[]
while unseen:
 i=min(unseen);orb=sorted(set(perms[:,i]));orbits.append(orb);unseen-=set(orb)
orbits=sorted(orbits,key=lambda o:(len(o),o[0]))
print('orbit sizes',[len(o) for o in orbits]);print('orbit representative signs',[sigs[o[0]].tolist() for o in orbits]);print('hamming weights on orbits',[[sum((sigs[k]>0)) for k in O[:3]] for O in orbits])
A=np.zeros((64,64),dtype=int)
for i in range(64):
 for k in range(6):
  s=sigs[i].copy();s[k]*=-1;j=s2i[tuple(s)];A[i,j]=1
assert np.all(A==A.T) and np.all(A.sum(axis=0)==6)
counts=np.zeros((4,4),dtype=int)
for a,O in enumerate(orbits):
 for b,Q in enumerate(orbits):
  counts[a,b]=A[np.ix_(O,Q)].sum()
print('edges by orbit total directed',counts,'\nper vertex',counts/np.array([len(o) for o in orbits])[:,None]);
# antipodes
anti=np.array([s2i[tuple(-s)] for s in sigs],int)
print('antipodal orbit permutation',[[b for b,Q in enumerate(orbits) if anti[O[0]] in Q][0] for O in orbits]);
# auto choose shell/face orbit pairing via Q6 adjacency: 12 orbit -> 20 orbit with 5 neighbors
for a,O in enumerate(orbits):
 if len(O)!=12:continue
 for b,Q in enumerate(orbits):
  if len(Q)!=20:continue
  B=A[np.ix_(O,Q)]
  if np.any(B):
   print('candidate',a,b,'B shape',B.shape,'rowdeg',np.unique(B.sum(axis=1),return_counts=True),'coldeg',np.unique(B.sum(axis=0),return_counts=True),'rank',np.linalg.matrix_rank(B))
   print('B B^T spec',np.round(np.linalg.eigvalsh(B@B.T),8))
   # 12 vertex pairs with shared faces counts 0/2/5?
   print('BB^T values',np.unique(B@B.T,return_counts=True))
# detect 20x20 adjacency via two-step 12-mediated (face adjacency maybe iff intersection two vertices)
for a,O in enumerate(orbits):
 if len(O)!=12:continue
 for b,Q in enumerate(orbits):
  if len(Q)!=20:continue
  B=A[np.ix_(O,Q)]
  if not B.sum():continue
  F=B.T@B
  for shared in [1,2,3]:
   H=(F==shared).astype(int);np.fill_diagonal(H,0)
   if np.all(H.sum(axis=0)==3):
    print('dodeca graph candidate',a,b,shared, 'isomorphic',nx.is_isomorphic(nx.from_numpy_array(H),nx.dodecahedral_graph()))
    hid=null_space(B).real
    L=np.diag(H.sum(axis=0))-H
    eigs=np.linalg.eigvalsh(hid.T@L@hid)
    print('hidden eigs',np.round(eigs,9))
# choose orbit order paired anti? actual interlayer face-face edge direct A
for a,O in enumerate(orbits):
 if len(O)!=20:continue
 for b,Q in enumerate(orbits):
  if b<=a or len(Q)!=20:continue
  print('20-20 direct adjacency',a,b, A[np.ix_(O,Q)].sum(), 'singulars',np.linalg.svd(A[np.ix_(O,Q)],compute_uv=False))
# new frontier: exact subspace and true cube dynamical coupling
V_A=orbits[0];V_B=orbits[1]; F_B=orbits[2];F_A=orbits[3]
B0=A[np.ix_(V_A,F_A)].astype(float)
B1=A[np.ix_(V_B,F_B)].astype(float)
C=A[np.ix_(F_A,F_B)].astype(float)
def hidden_frames(B):
    F=B.T@B
    D=(F==2).astype(float);np.fill_diagonal(D,0)
    L=np.diag(D.sum(axis=0))-D
    evals,evecs=np.linalg.eigh(L)
    ker=null_space(B)
    # hidden kernels are invariant under L. eigenvectors with near-zero B norms at lambdas 3 or 5
    hid3=np.column_stack([evecs[:,k] for k,e in enumerate(evals) if abs(e-3)<1e-8 and np.linalg.norm(B@evecs[:,k])<1e-8]);
    hid5=np.column_stack([evecs[:,k] for k,e in enumerate(evals) if abs(e-5)<1e-8 and np.linalg.norm(B@evecs[:,k])<1e-8]);
    assert hid3.shape==(20,4) and hid5.shape==(20,4)
    return L,hid3,hid5
L0,H03,H05=hidden_frames(B0);L1,H13,H15=hidden_frames(B1)
print('hidden blocks singulars 3->3',np.linalg.svd(H03.T@C@H13,compute_uv=False));
print('hidden blocks singulars 5->5',np.linalg.svd(H05.T@C@H15,compute_uv=False));
print('cross sectors',np.linalg.norm(H03.T@C@H15),np.linalg.norm(H05.T@C@H13))
print('invariance face 3',np.linalg.norm(B1@(C.T@H03)),np.linalg.norm(C@H13));print('invariance face5',np.linalg.norm(B1@(C.T@H05)))
Z=np.zeros((64,16))
Z[np.ix_(F_A,range(4))]=H03
Z[np.ix_(F_A,range(4,8))]=H05
Z[np.ix_(F_B,range(8,12))]=H13
Z[np.ix_(F_B,range(12,16))]=H15
assert np.linalg.norm(Z.T@Z-np.eye(16))<1e-12
print('16D hidden leakage',np.linalg.norm((np.eye(64)-Z@Z.T)@A@Z))
print('spectrum A hidden',np.linalg.eigvalsh(Z.T@A@Z))
# 13 subspace VA + F_A uniform
E13=np.zeros((64,13));E13[V_A, np.arange(12)]=1.;E13[F_A,12]=1/np.sqrt(20)
assert np.linalg.norm(E13.T@E13-np.eye(13))<1e-12
P13=E13@E13.T
leak=np.linalg.norm((np.eye(64)-P13)@A@E13)
print('13 subspace adjacency leakage',leak, 'leak_squared',leak**2)
print('13 P A P eigs',np.linalg.eigvalsh(E13.T@A@E13))
# ico adjacency reorder node correspondence; inherited VA orbit graph from BB^T
Aico=((B0@B0.T-5*np.eye(12))/2)
A2=A[np.ix_(V_A,range(64))]@A[:,V_A]
print('shell A2 = 6 I + 2 Aico residual',np.linalg.norm(A2 - (6*np.eye(12)+2*Aico)))
# centered graph 13, create adjacency shell Aico and unit radial links
Ac=np.zeros((13,13));Ac[:12,:12]=Aico;Ac[:12,12]=1;Ac[12,:12]=1
Lc=np.diag(Ac.sum(axis=0))-Ac
print('centered 13 Laplace spectrum',np.round(np.linalg.eigvalsh(Lc),10))
# Character multiplicity analysis of 64D signed-vertex representation
from collections import defaultdict
# cycle order of induced permutation on 64 sign states
cases=defaultdict(list)
for perm in perms:
  y=np.arange(64);power=0
  while True:
    y=perm[y];power+=1
    if np.array_equal(y,np.arange(64)):break
  tr=int(np.sum(perm==np.arange(64)))
  if power==5:
    # distinguish 5 classes via 3D rotation trace: source rots order identical to perms
    # use fixed points of 12D icosahedron graph action or angle trace
    pass
  cases[(power,tr)].append(perm)
print('A5 action order,trace classes',[(k,len(v)) for k,v in cases.items()])
# fixed points on each of orbit 12 and 20
counts_by_order=defaultdict(list)
for perm in perms:
 y=np.arange(64);order=0
 while True:
  y=perm[y];order+=1
  if np.array_equal(y,np.arange(64)): break
 fix=[sum(perm[i]==i for i in o) for o in orbits]
 counts_by_order[order].append(tuple(fix))
for order,vals in counts_by_order.items():
 print('fixed characters order',order,'reps',list(sorted(set(vals))),'count',len(vals))
# check multiplicities using class-averaging order 5 contribute 3+3' sums both =1 on 5 rotations
n2=15;n3=20;n5=24
chi_by_ord = {1:64,2:[k for k in cases if k[0]==2][0][1],3:[k for k in cases if k[0]==3][0][1],5:[k for k in cases if k[0]==5][0][1]}
print('character by order',chi_by_ord)
chi64=[chi_by_ord[x] for x in (1,2,3,5)]
mult1=(64+15*chi64[1]+20*chi64[2]+24*chi64[3])/60
mult4=(4*64+20*chi64[2]-24*chi64[3])/60
mult5=(5*64+15*chi64[1]-20*chi64[2])/60
multsum3=(6*64-30*chi64[1]+24*chi64[3])/60
print('A5 64 decomposition multiplicities 1, 4, 5, 3+3prime',mult1,mult4,mult5,multsum3)
# A5 representation block decomposition and spectra for full native Q6 adjacency
characters={"1":(1,[1,1,1,1,1]),"3":(3,[3,-1,0,phi,1-phi]),"3prime":(3,[3,-1,0,1-phi,phi]),"4":(4,[4,0,1,-1,-1]),"5":(5,[5,1,-1,0,0])}
projectors={}
for name,(d,ch) in characters.items():
 P=np.zeros((64,64))
 for iso,perm in zip(rots,perms):
  X=np.eye(64)[perm,:] # X_{i,j}=delta i,perm[j] ? construction eye[perm,:] gives row perm i, column i; actually P_g should rows perm[j], cols j, use np.eye(64)[:, inv_perm]? transpose? group sum class conjugate symmetric, okay sum character invariant either way
  perm_ord=1; cur=perm.copy()
  while not np.array_equal(cur,np.arange(64)):
   cur=perm[cur];perm_ord+=1
  if perm_ord==1:ix=0
  elif perm_ord==2:ix=1
  elif perm_ord==3:ix=2
  elif perm_ord==5:
   M=np.linalg.lstsq(vec,vec[[iso[i] for i in range(12)]],rcond=None)[0]
   tr=np.trace(M)
   ix=3 if tr>0 else 4
  else:raise ValueError(perm_ord)
  P+=ch[ix]*X
 P*=d/60
 assert np.linalg.norm(P@P-P)<1e-10 and np.linalg.norm(P-P.T)<1e-10,(name,np.linalg.norm(P@P-P))
 vals,U=np.linalg.eigh(P)
 W=U[:,vals>.5]
 lam=np.linalg.eigvalsh(W.T@A@W)
 print('A5 irrep',name,'isotypic rank',W.shape[1],'A eigenvalues',np.round(lam,8))
 projectors[name]=P
assert np.linalg.norm(sum(projectors.values())-np.eye(64))<1e-10
# Exact analytic visible-shell resolvent from 64-state Q6
shell=np.zeros((64,12));shell[V_A,range(12)]=1
weights={'singlet':[(3/8,36),(5/8,4)],
 'triplet+':[((3+np.sqrt(5))/8,16),(1-(3+np.sqrt(5))/8,0)],
 'triplet-':[((3-np.sqrt(5))/8,16),(1-(3-np.sqrt(5))/8,0)],
 'fiveplet':[(1,4)]}
for z in (6.5,7.0,13.0,3.5+0.25j):
 Gfull=shell.T@np.linalg.inv(z*np.eye(64)-A)@shell
 lam,U=np.linalg.eigh(Aico)
 Gformula=np.zeros((12,12),dtype=complex)
 for v,iv in [(5,'singlet'),(np.sqrt(5),'triplet+'),(-np.sqrt(5),'triplet-'),(-1,'fiveplet')]:
  E=U[:,np.abs(lam-v)<1e-8];P=E@E.T
  g=sum(w*z/(z*z-r) if r else w/z for w,r in weights[iv])
  Gformula+=g*P
 print('visible full Q6 resolvent z',z,'residual',np.linalg.norm(Gfull-Gformula),'eigs',np.round(np.linalg.eigvals(Gformula),9))
# complete visible H13 exact Schur resolvent: two-dimensional singlet + 3+3'+5
shell_icosa_eigs,U12=np.linalg.eigh(Aico)
recon_weights={'triplet+':((3+np.sqrt(5))/8,16),'triplet-':((3-np.sqrt(5))/8,16)}
uVA=E13[:,:12]@np.ones(12)/np.sqrt(12)
uFA=E13[:,12]
Qfull=np.column_stack([uVA,uFA,*[E13[:,:12]@U12[:,k] for k,v in enumerate(shell_icosa_eigs) if abs(v-5)>1e-8]])
assert np.linalg.norm(Qfull.T@Qfull-np.eye(13))<1e-10
for z in (7.0,13.0,3.5+.25j):
 C0=np.array([[0,np.sqrt(15)],[np.sqrt(15),0]])
 D0=np.diag([1,3])
 K0=z*np.eye(2)-C0-D0@np.linalg.inv(z*np.eye(2)-C0)@D0
 G0=np.linalg.inv(K0)
 G13full=E13.T@np.linalg.inv(z*np.eye(64)-A)@E13
 G13formula=np.zeros((13,13),dtype=complex)
 # populate singlet frame
 Z0=np.zeros((13,2));Z0[:12,0]=1/np.sqrt(12);Z0[12,1]=1
 G13formula += Z0@G0@Z0.T
 for eig,key in [(np.sqrt(5),'triplet+'),(-np.sqrt(5),'triplet-'),(-1,'fiveplet')]:
  ind=np.abs(shell_icosa_eigs-eig)<1e-8
  Q=U12[:,ind]
  if key=='fiveplet':g=z/(z*z-4)
  else:
   alpha,_=recon_weights[key]
   g=(1-alpha)/z+alpha*z/(z*z-16)
  Z=np.zeros((13,Q.shape[1]));Z[:12,:]=Q
  G13formula+=g*(Z@Z.T)
 print('complete H13 Schur resolvent z',z,'residual',np.linalg.norm(G13full-G13formula))
H16=np.zeros((64,16));H16[np.ix_(F_A,range(4))]=H03;H16[np.ix_(F_A,range(4,8))]=H05;H16[np.ix_(F_B,range(8,12))]=H13;H16[np.ix_(F_B,range(12,16))]=H15
print('hidden16 vs H13 overlap',np.linalg.norm(H16.T@E13))
# Full exact cube vs analytic hidden-sector transfer: H5 rotation by alpha angle
from scipy.linalg import expm
v=np.zeros(64);v[F_A]=H05[:,0]
for t in [np.pi/4,2*np.pi/phi**2]:
 evolved=expm(-1j*t*A.astype(float))@v
 probB=float(np.sum(abs(evolved[F_B])**2))
 probA=float(np.sum(abs(evolved[F_A])**2))
 print('t',t,'probB',probB,'sin^2(2t)',np.sin(2*t)**2,'probA',probA,'offface',np.linalg.norm(evolved[[k for k in range(64) if k not in F_A and k not in F_B]]))
